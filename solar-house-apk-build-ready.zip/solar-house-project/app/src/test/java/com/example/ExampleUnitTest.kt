package com.example

import com.example.data.model.CableSizingInput
import com.example.data.model.FaultCategory
import com.example.data.model.PlantSizingInput
import com.example.data.model.StringSizingInput
import com.example.data.model.TiltPitchInput
import com.example.data.repository.InverterKnowledgeBase
import com.example.util.SolarCalculators
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ExampleUnitTest {

    @Test
    fun testPlantSizingCalculations() {
        val input = PlantSizingInput(
            dailyKwhNeed = 50.0,
            peakSunHours = 4.5,
            systemLossFactorPercent = 20.0,
            moduleWattageWp = 500.0,
            targetDcAcRatio = 1.25
        )
        val result = SolarCalculators.calculatePlantSizing(input)

        // 50 kWh / 0.8 = 62.5 gross kWh -> 62.5 / 4.5 = 13.88 kWp
        assertTrue(result.requiredDcCapacityKwp > 13.0)
        assertTrue(result.totalModulesCount >= 28)
        assertTrue(result.estimatedDailyGenerationKwh > 40.0)
    }

    @Test
    fun testStringSizingTemperatureCoefficient() {
        val input = StringSizingInput(
            moduleVocStc = 50.0,
            tempCoeffVocPercent = -0.3,
            siteMinTempC = -10.0, // delta T = -35C -> +10.5% Voc
            inverterMaxDcVoltage = 1000.0
        )
        val result = SolarCalculators.calculateStringSizing(input)

        // At -10C, Voc is ~55.25V
        assertTrue(result.vocColdExtreme > 54.0)
        // Max modules in series must ensure Voc * N <= 1000V
        assertTrue(result.maxModulesPerString <= 18)
        assertTrue(result.isVocWithinSafeLimit)
    }

    @Test
    fun testCableVoltageDropCompliance() {
        // DC string with 4mm2 cable over 50m at 600V, 13A
        val compliantInput = CableSizingInput(
            circuitType = "DC String",
            voltageV = 600.0,
            currentAmps = 13.0,
            oneWayLengthM = 30.0,
            cableCrossSectionMm2 = 4.0,
            conductorMaterial = "Copper"
        )
        val compliantResult = SolarCalculators.calculateCableSizing(compliantInput)
        assertTrue(compliantResult.voltageDropPercent < 2.0)
        assertTrue(compliantResult.isCompliant)

        // Undersized cable over long run
        val nonCompliantInput = CableSizingInput(
            circuitType = "DC String",
            voltageV = 600.0,
            currentAmps = 25.0,
            oneWayLengthM = 150.0,
            cableCrossSectionMm2 = 4.0,
            conductorMaterial = "Copper"
        )
        val nonCompliantResult = SolarCalculators.calculateCableSizing(nonCompliantInput)
        assertTrue(nonCompliantResult.voltageDropPercent > 2.0)
        assertFalse(nonCompliantResult.isCompliant)
    }

    @Test
    fun testInverterKnowledgeBaseSearch() {
        val searchRiso = InverterKnowledgeBase.searchFaults("Riso", "All Brands", FaultCategory.ALL)
        assertTrue(searchRiso.isNotEmpty())
        assertEquals("Sungrow", searchRiso.first().brand)

        val smaFaults = InverterKnowledgeBase.searchFaults("", "SMA", FaultCategory.ALL)
        assertTrue(smaFaults.isNotEmpty())
        assertTrue(smaFaults.all { it.brand == "SMA" })
    }
}
