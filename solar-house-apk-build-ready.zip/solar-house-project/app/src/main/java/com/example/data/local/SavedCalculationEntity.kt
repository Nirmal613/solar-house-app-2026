package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "saved_calculations")
data class SavedCalculationEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val title: String,
    val calculationType: String,
    val summary: String,
    val details: String,
    val createdAt: Long = System.currentTimeMillis()
)
