package com.example.data.local

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface SolarHouseDao {

    // Maintenance Logs
    @Query("SELECT * FROM maintenance_logs ORDER BY timestamp DESC")
    fun getAllMaintenanceLogs(): Flow<List<MaintenanceLogEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMaintenanceLog(log: MaintenanceLogEntity): Long

    @Update
    suspend fun updateMaintenanceLog(log: MaintenanceLogEntity)

    @Delete
    suspend fun deleteMaintenanceLog(log: MaintenanceLogEntity)

    @Query("SELECT COUNT(*) FROM maintenance_logs")
    suspend fun getMaintenanceLogsCount(): Int

    // Customer Service Tickets
    @Query("SELECT * FROM customer_service_tickets ORDER BY createdAt DESC")
    fun getAllCustomerTickets(): Flow<List<CustomerServiceTicketEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCustomerTicket(ticket: CustomerServiceTicketEntity): Long

    @Update
    suspend fun updateCustomerTicket(ticket: CustomerServiceTicketEntity)

    @Delete
    suspend fun deleteCustomerTicket(ticket: CustomerServiceTicketEntity)

    @Query("SELECT COUNT(*) FROM customer_service_tickets")
    suspend fun getCustomerTicketsCount(): Int

    // Saved Calculations
    @Query("SELECT * FROM saved_calculations ORDER BY createdAt DESC")
    fun getAllSavedCalculations(): Flow<List<SavedCalculationEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSavedCalculation(calc: SavedCalculationEntity): Long

    @Delete
    suspend fun deleteSavedCalculation(calc: SavedCalculationEntity)
}
