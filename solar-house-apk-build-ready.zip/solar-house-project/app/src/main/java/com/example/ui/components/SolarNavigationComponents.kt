package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Calculate
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.HeadsetMic
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.SupportAgent
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.ui.theme.SolarAmber
import com.example.ui.theme.SolarGreen
import com.example.ui.theme.SolarNavy
import com.example.ui.theme.SolarNavyLight
import com.example.ui.viewmodel.ScreenTab

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SolarTopBar(
    currentTab: ScreenTab,
    onEmergencyCallClick: () -> Unit,
    onWhatsAppClick: () -> Unit
) {
    val title = when (currentTab) {
        ScreenTab.DASHBOARD -> "Solar House"
        ScreenTab.CALCULATORS -> "Engineering Sizing"
        ScreenTab.OM_MANAGEMENT -> "Plant O&M Suite"
        ScreenTab.TROUBLESHOOTING -> "Inverter Diagnostics"
        ScreenTab.CUSTOMER_SERVICES -> "Customer Services"
    }

    val subtitle = when (currentTab) {
        ScreenTab.DASHBOARD -> "EPC & Plant Operations"
        ScreenTab.CALCULATORS -> "IEC / NEC Standards"
        ScreenTab.OM_MANAGEMENT -> "Field Inspections & PR"
        ScreenTab.TROUBLESHOOTING -> "Multi-Brand Knowledge"
        ScreenTab.CUSTOMER_SERVICES -> "Warranty & Surveys"
    }

    TopAppBar(
        colors = TopAppBarDefaults.topAppBarColors(
            containerColor = SolarNavy,
            titleContentColor = Color.White
        ),
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .background(
                            brush = Brush.radialGradient(
                                colors = listOf(SolarAmber, Color(0xFFB45309))
                            ),
                            shape = CircleShape
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        painter = painterResource(id = R.drawable.ic_launcher_foreground),
                        contentDescription = "Solar House Icon",
                        tint = Color.Unspecified,
                        modifier = Modifier.size(28.dp)
                    )
                }
                Spacer(modifier = Modifier.width(10.dp))
                androidx.compose.foundation.layout.Column {
                    Text(
                        text = title,
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = Color.White,
                            fontSize = 17.sp
                        )
                    )
                    Text(
                        text = subtitle,
                        style = MaterialTheme.typography.bodySmall.copy(
                            color = Color(0xFF94A3B8),
                            fontSize = 11.sp
                        )
                    )
                }
            }
        },
        actions = {
            FilledIconButton(
                onClick = onWhatsAppClick,
                colors = IconButtonDefaults.filledIconButtonColors(
                    containerColor = SolarGreen,
                    contentColor = Color.White
                ),
                modifier = Modifier
                    .size(38.dp)
                    .testTag("whatsapp_top_btn")
            ) {
                Icon(
                    imageVector = Icons.Default.HeadsetMic,
                    contentDescription = "WhatsApp Engineering Support",
                    modifier = Modifier.size(19.dp)
                )
            }
            Spacer(modifier = Modifier.width(6.dp))
            FilledIconButton(
                onClick = onEmergencyCallClick,
                colors = IconButtonDefaults.filledIconButtonColors(
                    containerColor = SolarNavyLight,
                    contentColor = SolarAmber
                ),
                modifier = Modifier
                    .size(38.dp)
                    .padding(end = 4.dp)
                    .testTag("call_engineer_top_btn")
            ) {
                Icon(
                    imageVector = Icons.Default.Phone,
                    contentDescription = "Call Engineer",
                    modifier = Modifier.size(19.dp)
                )
            }
        }
    )
}

@Composable
fun SolarBottomNav(
    currentTab: ScreenTab,
    onTabSelected: (ScreenTab) -> Unit
) {
    NavigationBar(
        containerColor = SolarNavy,
        contentColor = Color.White,
        tonalElevation = 8.dp
    ) {
        NavigationBarItem(
            selected = currentTab == ScreenTab.DASHBOARD,
            onClick = { onTabSelected(ScreenTab.DASHBOARD) },
            icon = { Icon(Icons.Default.Dashboard, contentDescription = "Overview") },
            label = { Text("Overview", fontSize = 11.sp) },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = SolarNavy,
                selectedTextColor = SolarAmber,
                indicatorColor = SolarAmber,
                unselectedIconColor = Color(0xFF94A3B8),
                unselectedTextColor = Color(0xFF94A3B8)
            ),
            modifier = Modifier.testTag("nav_tab_dashboard")
        )

        NavigationBarItem(
            selected = currentTab == ScreenTab.CALCULATORS,
            onClick = { onTabSelected(ScreenTab.CALCULATORS) },
            icon = { Icon(Icons.Default.Calculate, contentDescription = "Calculators") },
            label = { Text("Calculators", fontSize = 11.sp) },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = SolarNavy,
                selectedTextColor = SolarAmber,
                indicatorColor = SolarAmber,
                unselectedIconColor = Color(0xFF94A3B8),
                unselectedTextColor = Color(0xFF94A3B8)
            ),
            modifier = Modifier.testTag("nav_tab_calculators")
        )

        NavigationBarItem(
            selected = currentTab == ScreenTab.OM_MANAGEMENT,
            onClick = { onTabSelected(ScreenTab.OM_MANAGEMENT) },
            icon = { Icon(Icons.Default.Build, contentDescription = "Plant O&M") },
            label = { Text("Plant O&M", fontSize = 11.sp) },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = SolarNavy,
                selectedTextColor = SolarAmber,
                indicatorColor = SolarAmber,
                unselectedIconColor = Color(0xFF94A3B8),
                unselectedTextColor = Color(0xFF94A3B8)
            ),
            modifier = Modifier.testTag("nav_tab_om")
        )

        NavigationBarItem(
            selected = currentTab == ScreenTab.TROUBLESHOOTING,
            onClick = { onTabSelected(ScreenTab.TROUBLESHOOTING) },
            icon = { Icon(Icons.Default.Warning, contentDescription = "Troubleshoot") },
            label = { Text("Diagnostic", fontSize = 11.sp) },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = SolarNavy,
                selectedTextColor = SolarAmber,
                indicatorColor = SolarAmber,
                unselectedIconColor = Color(0xFF94A3B8),
                unselectedTextColor = Color(0xFF94A3B8)
            ),
            modifier = Modifier.testTag("nav_tab_troubleshoot")
        )

        NavigationBarItem(
            selected = currentTab == ScreenTab.CUSTOMER_SERVICES,
            onClick = { onTabSelected(ScreenTab.CUSTOMER_SERVICES) },
            icon = { Icon(Icons.Default.SupportAgent, contentDescription = "Services") },
            label = { Text("Services", fontSize = 11.sp) },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = SolarNavy,
                selectedTextColor = SolarAmber,
                indicatorColor = SolarAmber,
                unselectedIconColor = Color(0xFF94A3B8),
                unselectedTextColor = Color(0xFF94A3B8)
            ),
            modifier = Modifier.testTag("nav_tab_services")
        )
    }
}
