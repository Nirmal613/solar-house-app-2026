package com.example

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarDuration
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.components.SolarBottomNav
import com.example.ui.components.SolarTopBar
import com.example.ui.components.WhatsAppModal
import com.example.ui.screens.CustomerServicesScreen
import com.example.ui.screens.DashboardScreen
import com.example.ui.screens.EngineeringCalculatorsScreen
import com.example.ui.screens.InverterTroubleshootingScreen
import com.example.ui.screens.OmManagementScreen
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.viewmodel.ScreenTab
import com.example.ui.viewmodel.SolarHouseViewModel
import com.example.util.WhatsAppHelper

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                SolarHouseApp()
            }
        }
    }
}

@Composable
fun SolarHouseApp(
    viewModel: SolarHouseViewModel = viewModel()
) {
    val context = LocalContext.current
    val currentTab by viewModel.currentTab.collectAsState()
    val notification by viewModel.notification.collectAsState()
    val showWhatsAppDialog by viewModel.showWhatsAppDialog.collectAsState()
    val whatsAppInitialMessage by viewModel.whatsAppInitialMessage.collectAsState()

    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(notification) {
        notification?.let {
            snackbarHostState.showSnackbar(
                message = it.message,
                duration = SnackbarDuration.Short
            )
            viewModel.clearNotification()
        }
    }

    // Handle system back navigation: return to Dashboard first if on sub-tab
    BackHandler(enabled = currentTab != ScreenTab.DASHBOARD) {
        viewModel.setScreenTab(ScreenTab.DASHBOARD)
    }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        topBar = {
            SolarTopBar(
                currentTab = currentTab,
                onEmergencyCallClick = {
                    WhatsAppHelper.dialPhone(context, WhatsAppHelper.DEFAULT_SOLAR_HOUSE_PHONE)
                },
                onWhatsAppClick = {
                    viewModel.openWhatsAppDialogWithMessage(
                        "Hello Solar House Engineering Support, I need assistance with our solar plant."
                    )
                }
            )
        },
        bottomBar = {
            SolarBottomNav(
                currentTab = currentTab,
                onTabSelected = { viewModel.setScreenTab(it) }
            )
        },
        snackbarHost = {
            SnackbarHost(hostState = snackbarHostState)
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            AnimatedContent(
                targetState = currentTab,
                transitionSpec = { fadeIn() togetherWith fadeOut() },
                label = "screen_tab_transition"
            ) { tab ->
                when (tab) {
                    ScreenTab.DASHBOARD -> DashboardScreen(
                        viewModel = viewModel,
                        onNavigate = { viewModel.setScreenTab(it) }
                    )
                    ScreenTab.CALCULATORS -> EngineeringCalculatorsScreen(
                        viewModel = viewModel
                    )
                    ScreenTab.OM_MANAGEMENT -> OmManagementScreen(
                        viewModel = viewModel
                    )
                    ScreenTab.TROUBLESHOOTING -> InverterTroubleshootingScreen(
                        viewModel = viewModel
                    )
                    ScreenTab.CUSTOMER_SERVICES -> CustomerServicesScreen(
                        viewModel = viewModel
                    )
                }
            }
        }
    }

    if (showWhatsAppDialog) {
        WhatsAppModal(
            initialMessage = whatsAppInitialMessage,
            onDismiss = { viewModel.dismissWhatsAppDialog() }
        )
    }
}
