package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "customer_service_tickets")
data class CustomerServiceTicketEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val customerName: String,
    val customerPhone: String,
    val siteAddress: String,
    val requestType: String, // "New Site Survey", "O&M Service Request", "Inverter Warranty Claim", "Emergency Breakdown"
    val systemCapacityKwp: Double,
    val inverterBrand: String,
    val issueDescription: String,
    val urgency: String, // "Low", "Medium", "High", "Emergency"
    val ticketStatus: String, // "Open", "In Progress", "Resolved"
    val createdAt: Long = System.currentTimeMillis()
)
