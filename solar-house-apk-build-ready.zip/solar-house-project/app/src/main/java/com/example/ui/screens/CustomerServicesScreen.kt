package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.SupportAgent
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.CustomerServiceTicketEntity
import com.example.ui.theme.SolarAmber
import com.example.ui.theme.SolarGreen
import com.example.ui.theme.SolarNavy
import com.example.ui.theme.SolarRed
import com.example.ui.viewmodel.SolarHouseViewModel
import com.example.util.WhatsAppHelper

@Composable
fun CustomerServicesScreen(
    viewModel: SolarHouseViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val tickets by viewModel.filteredCustomerTickets.collectAsState()
    val activeFilter by viewModel.ticketStatusFilter.collectAsState()
    var showCreateDialog by remember { mutableStateOf(false) }

    val statusFilters = listOf("All", "Open", "In Progress", "Resolved")

    Scaffold(
        modifier = modifier.fillMaxSize(),
        containerColor = Color(0xFFF8FAFC),
        floatingActionButton = {
            FloatingActionButton(
                onClick = { showCreateDialog = true },
                containerColor = SolarAmber,
                contentColor = SolarNavy,
                modifier = Modifier
                    .padding(bottom = 70.dp)
                    .testTag("add_ticket_fab")
            ) {
                Icon(Icons.Default.Add, contentDescription = "Create Customer Ticket")
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Status Filter Tabs
            LazyRow(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp),
                contentPadding = PaddingValues(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(statusFilters) { filter ->
                    FilterChip(
                        selected = activeFilter == filter,
                        onClick = { viewModel.setTicketStatusFilter(filter) },
                        label = { Text(filter, fontSize = 11.sp) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = SolarNavy,
                            selectedLabelColor = Color.White
                        )
                    )
                }
            }

            if (tickets.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(32.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            imageVector = Icons.Default.SupportAgent,
                            contentDescription = null,
                            tint = Color(0xFF94A3B8),
                            modifier = Modifier.size(48.dp)
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "No customer tickets in '$activeFilter'",
                            color = Color(0xFF64748B),
                            fontSize = 14.sp
                        )
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 16.dp),
                    contentPadding = PaddingValues(bottom = 90.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(tickets, key = { it.id }) { ticket ->
                        CustomerTicketCard(
                            ticket = ticket,
                            onStatusChange = { newStatus ->
                                viewModel.updateCustomerTicketStatus(ticket, newStatus)
                            },
                            onDelete = { viewModel.deleteCustomerTicket(ticket) },
                            onWhatsAppClick = {
                                val msg = """
                                    Hello ${ticket.customerName},
                                    This is Solar House Engineering regarding your ticket #${ticket.id} (${ticket.requestType}).
                                    Status: ${ticket.ticketStatus}
                                    System: ${ticket.systemCapacityKwp} kWp (${ticket.inverterBrand})
                                    We are following up on your request.
                                """.trimIndent()
                                WhatsAppHelper.openWhatsApp(context, ticket.customerPhone, msg)
                            },
                            onCallClick = {
                                WhatsAppHelper.dialPhone(context, ticket.customerPhone)
                            }
                        )
                    }
                }
            }
        }
    }

    if (showCreateDialog) {
        CreateTicketDialog(
            onDismiss = { showCreateDialog = false },
            onConfirm = { newTicket ->
                viewModel.addCustomerTicket(newTicket)
                showCreateDialog = false
            }
        )
    }
}

@Composable
fun CustomerTicketCard(
    ticket: CustomerServiceTicketEntity,
    onStatusChange: (String) -> Unit,
    onDelete: () -> Unit,
    onWhatsAppClick: () -> Unit,
    onCallClick: () -> Unit
) {
    var showStatusMenu by remember { mutableStateOf(false) }

    ElevatedCard(
        colors = CardDefaults.elevatedCardColors(containerColor = Color.White),
        elevation = CardDefaults.elevatedCardElevation(defaultElevation = 2.dp),
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = ticket.customerName,
                        fontWeight = FontWeight.Bold,
                        color = SolarNavy,
                        fontSize = 15.sp
                    )
                    Text(
                        text = "${ticket.siteAddress} • ${ticket.customerPhone}",
                        color = Color(0xFF64748B),
                        fontSize = 11.sp
                    )
                }

                // Urgency Badge
                Surface(
                    color = when (ticket.urgency) {
                        "Emergency" -> SolarRed.copy(alpha = 0.15f)
                        "High" -> SolarAmber.copy(alpha = 0.15f)
                        else -> Color(0xFFE2E8F0)
                    },
                    shape = RoundedCornerShape(4.dp)
                ) {
                    Text(
                        text = "${ticket.urgency} Priority",
                        color = when (ticket.urgency) {
                            "Emergency" -> SolarRed
                            "High" -> SolarAmber
                            else -> Color(0xFF475569)
                        },
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Details row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    color = SolarNavy.copy(alpha = 0.08f),
                    shape = RoundedCornerShape(4.dp)
                ) {
                    Text(
                        text = ticket.requestType,
                        color = SolarNavy,
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.sp,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }

                Text(
                    text = "${ticket.systemCapacityKwp} kWp • ${ticket.inverterBrand}",
                    fontSize = 11.sp,
                    color = Color(0xFF475569),
                    fontWeight = FontWeight.SemiBold
                )
            }

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = ticket.issueDescription,
                fontSize = 12.sp,
                color = Color(0xFF334155),
                lineHeight = 16.sp
            )

            Spacer(modifier = Modifier.height(10.dp))

            // Footer Actions
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Status Switcher
                Box {
                    Surface(
                        color = when (ticket.ticketStatus) {
                            "Resolved" -> SolarGreen.copy(alpha = 0.15f)
                            "In Progress" -> SolarAmber.copy(alpha = 0.15f)
                            else -> Color(0xFFE2E8F0)
                        },
                        shape = RoundedCornerShape(6.dp),
                        modifier = Modifier.clickable { showStatusMenu = true }
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Status: ${ticket.ticketStatus} ▾",
                                color = when (ticket.ticketStatus) {
                                    "Resolved" -> SolarGreen
                                    "In Progress" -> SolarAmber
                                    else -> Color(0xFF475569)
                                },
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    DropdownMenu(
                        expanded = showStatusMenu,
                        onDismissRequest = { showStatusMenu = false }
                    ) {
                        listOf("Open", "In Progress", "Resolved").forEach { status ->
                            DropdownMenuItem(
                                text = { Text(status) },
                                onClick = {
                                    onStatusChange(status)
                                    showStatusMenu = false
                                }
                            )
                        }
                    }
                }

                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    IconButton(onClick = onDelete, modifier = Modifier.size(32.dp)) {
                        Icon(Icons.Default.Delete, contentDescription = "Delete", tint = SolarRed, modifier = Modifier.size(16.dp))
                    }

                    OutlinedButton(
                        onClick = onCallClick,
                        shape = RoundedCornerShape(6.dp),
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                    ) {
                        Icon(Icons.Default.Phone, contentDescription = null, tint = SolarNavy, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(3.dp))
                        Text("Call", fontSize = 11.sp, color = SolarNavy)
                    }

                    Button(
                        onClick = onWhatsAppClick,
                        colors = ButtonDefaults.buttonColors(containerColor = SolarGreen, contentColor = Color.White),
                        shape = RoundedCornerShape(6.dp),
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                    ) {
                        Icon(Icons.Default.Chat, contentDescription = null, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(3.dp))
                        Text("WhatsApp", fontSize = 11.sp)
                    }
                }
            }
        }
    }
}

@Composable
fun CreateTicketDialog(
    onDismiss: () -> Unit,
    onConfirm: (CustomerServiceTicketEntity) -> Unit
) {
    var name by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var address by remember { mutableStateOf("") }
    var requestType by remember { mutableStateOf("New Site Survey") }
    var capacityStr by remember { mutableStateOf("25") }
    var inverterBrand by remember { mutableStateOf("Sungrow") }
    var urgency by remember { mutableStateOf("Medium") }
    var description by remember { mutableStateOf("") }

    val requestTypes = listOf("New Site Survey", "O&M Service Request", "Inverter Warranty Claim", "Emergency Breakdown")
    val urgencies = listOf("Low", "Medium", "High", "Emergency")

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("New Customer Service / Survey", fontWeight = FontWeight.Bold, fontSize = 16.sp) },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Customer / Enterprise Name") },
                    modifier = Modifier.fillMaxWidth().testTag("ticket_name_input")
                )

                OutlinedTextField(
                    value = phone,
                    onValueChange = { phone = it },
                    label = { Text("Phone Number") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                    modifier = Modifier.fillMaxWidth().testTag("ticket_phone_input")
                )

                OutlinedTextField(
                    value = address,
                    onValueChange = { address = it },
                    label = { Text("Site Address / Location") },
                    modifier = Modifier.fillMaxWidth()
                )

                Text("Request Type:", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(requestTypes) { type ->
                        FilterChip(
                            selected = requestType == type,
                            onClick = { requestType = type },
                            label = { Text(type, fontSize = 10.sp) }
                        )
                    }
                }

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = capacityStr,
                        onValueChange = { capacityStr = it },
                        label = { Text("Capacity (kWp)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = inverterBrand,
                        onValueChange = { inverterBrand = it },
                        label = { Text("Inverter Brand") },
                        modifier = Modifier.weight(1f)
                    )
                }

                Text("Urgency Level:", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(urgencies) { urg ->
                        FilterChip(
                            selected = urgency == urg,
                            onClick = { urgency = urg },
                            label = { Text(urg, fontSize = 10.sp) }
                        )
                    }
                }

                OutlinedTextField(
                    value = description,
                    onValueChange = { description = it },
                    label = { Text("Issue / Survey Scope Details") },
                    minLines = 3,
                    modifier = Modifier.fillMaxWidth().testTag("ticket_desc_input")
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (name.isNotBlank()) {
                        val ticket = CustomerServiceTicketEntity(
                            customerName = name,
                            customerPhone = phone.ifBlank { "+919876543210" },
                            siteAddress = address.ifBlank { "Client Site" },
                            requestType = requestType,
                            systemCapacityKwp = capacityStr.toDoubleOrNull() ?: 10.0,
                            inverterBrand = inverterBrand.ifBlank { "Generic" },
                            issueDescription = description.ifBlank { "Requested consultation" },
                            urgency = urgency,
                            ticketStatus = "Open"
                        )
                        onConfirm(ticket)
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = SolarAmber, contentColor = SolarNavy),
                modifier = Modifier.testTag("save_ticket_confirm_btn")
            ) {
                Text("Submit Ticket")
            }
        },
        dismissButton = {
            OutlinedButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}
