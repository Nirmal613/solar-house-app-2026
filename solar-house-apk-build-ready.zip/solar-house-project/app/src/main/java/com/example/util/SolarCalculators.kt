package com.example.util

import com.example.data.model.CableSizingInput
import com.example.data.model.CableSizingResult
import com.example.data.model.FinancialYieldInput
import com.example.data.model.FinancialYieldResult
import com.example.data.model.PlantSizingInput
import com.example.data.model.PlantSizingResult
import com.example.data.model.StringSizingInput
import com.example.data.model.StringSizingResult
import com.example.data.model.TiltPitchInput
import com.example.data.model.TiltPitchResult
import kotlin.math.ceil
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.round
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.math.tan

object SolarCalculators {

    fun calculatePlantSizing(input: PlantSizingInput): PlantSizingResult {
        val lossFactor = (input.systemLossFactorPercent / 100.0).coerceIn(0.05, 0.45)
        val psh = max(1.0, input.peakSunHours)
        val dailyGrossKwh = input.dailyKwhNeed / (1.0 - lossFactor)
        val requiredDcKwp = dailyGrossKwh / psh

        val moduleWp = max(50.0, input.moduleWattageWp)
        val totalModules = ceil((requiredDcKwp * 1000.0) / moduleWp).toInt().coerceAtLeast(1)
        val actualDcKwp = (totalModules * moduleWp) / 1000.0

        val dcAcRatio = max(0.8, input.targetDcAcRatio)
        val recommendedAcKw = round((actualDcKwp / dcAcRatio) * 10.0) / 10.0

        val singleModuleAreaSqM = input.moduleLengthM * input.moduleWidthM
        val totalAreaSqM = round((totalModules * singleModuleAreaSqM) * 10.0) / 10.0
        val totalAreaSqFt = round((totalAreaSqM * 10.7639) * 10.0) / 10.0

        val estDailyKwh = round((actualDcKwp * psh * (1.0 - lossFactor)) * 10.0) / 10.0
        val estMonthlyKwh = round((estDailyKwh * 30.4) * 10.0) / 10.0
        val estAnnualKwh = round((estDailyKwh * 365.0) * 10.0) / 10.0

        return PlantSizingResult(
            requiredDcCapacityKwp = round(actualDcKwp * 100.0) / 100.0,
            recommendedInverterAcKw = recommendedAcKw,
            totalModulesCount = totalModules,
            totalArrayAreaSqM = totalAreaSqM,
            totalArrayAreaSqFt = totalAreaSqFt,
            estimatedDailyGenerationKwh = estDailyKwh,
            estimatedMonthlyGenerationKwh = estMonthlyKwh,
            estimatedAnnualGenerationKwh = estAnnualKwh
        )
    }

    fun calculateStringSizing(input: StringSizingInput): StringSizingResult {
        // Extreme cold temperature Voc
        val deltaTCold = input.siteMinTempC - 25.0
        val vocCold = input.moduleVocStc * (1.0 + (input.tempCoeffVocPercent / 100.0) * deltaTCold)

        // Extreme summer operating temperature Vmp
        val maxCellTemp = input.siteMaxTempC + input.maxCellTempRiseC
        val deltaTHot = maxCellTemp - 25.0
        val vmpHot = input.moduleVmpStc * (1.0 + (input.tempCoeffVmpPercent / 100.0) * deltaTHot)

        // Max modules per string limited by Inverter Max DC Voltage at cold temperature
        val maxByVoc = (input.inverterMaxDcVoltage / vocCold).toInt().coerceAtLeast(1)
        val maxByMppt = (input.inverterMpptMaxVoltage / input.moduleVmpStc).toInt().coerceAtLeast(1)
        val maxModules = min(maxByVoc, maxByMppt)

        // Min modules per string limited by Inverter Min MPPT Voltage at hot temperature
        val minModules = ceil(input.inverterMpptMinVoltage / vmpHot).toInt().coerceAtLeast(1)

        val recommended = if (maxModules >= minModules) {
            ((minModules + maxModules) / 2)
        } else {
            maxModules
        }

        val stringsPerMppt = (input.inverterMaxCurrentPerMppt / input.moduleIscStc).toInt().coerceAtLeast(1)

        val isVocSafe = (vocCold * recommended) <= input.inverterMaxDcVoltage
        val isVmpInWindow = (vmpHot * recommended) >= input.inverterMpptMinVoltage &&
                (input.moduleVmpStc * recommended) <= input.inverterMpptMaxVoltage

        val report = buildString {
            append("Voc cold ($deltaTCold°C): ${round(vocCold * 10.0) / 10.0}V. ")
            append("Vmp hot ($maxCellTemp°C): ${round(vmpHot * 10.0) / 10.0}V. ")
            if (isVocSafe && isVmpInWindow) {
                append("Safe string range: $minModules to $maxModules modules.")
            } else {
                append("Warning: Check inverter voltage window or temperature limits.")
            }
        }

        return StringSizingResult(
            vocColdExtreme = round(vocCold * 10.0) / 10.0,
            vmpHotExtreme = round(vmpHot * 10.0) / 10.0,
            maxModulesPerString = maxModules,
            minModulesPerString = minModules,
            recommendedModulesPerString = recommended,
            maxStringsPerMppt = stringsPerMppt,
            isVocWithinSafeLimit = isVocSafe,
            isVmpWithinMpptRange = isVmpInWindow,
            summaryReport = report
        )
    }

    fun calculateCableSizing(input: CableSizingInput): CableSizingResult {
        // Resistivity ohm*mm^2 / m
        val rho = if (input.conductorMaterial.equals("Aluminum", ignoreCase = true)) 0.028 else 0.0175
        val length = max(1.0, input.oneWayLengthM)
        val area = max(1.0, input.cableCrossSectionMm2)
        val current = max(0.1, input.currentAmps)
        val voltage = max(12.0, input.voltageV)

        val is3Phase = input.circuitType.contains("3-Phase", ignoreCase = true)
        val powerFactor = 0.98

        val voltageDrop = if (is3Phase) {
            // sqrt(3) * L * I * rho * cosPhi / A
            (1.73205 * length * current * rho * powerFactor) / area
        } else {
            // 2 * L * I * rho / A
            (2.0 * length * current * rho) / area
        }

        val voltageDropPercent = (voltageDrop / voltage) * 100.0

        // Resistance R = loop length * rho / A
        val rLoop = if (is3Phase) (length * rho) / area else (2.0 * length * rho) / area
        val powerLoss = if (is3Phase) 3.0 * current * current * rLoop else current * current * rLoop

        val maxAllowed = if (input.circuitType.startsWith("DC", ignoreCase = true)) 2.0 else 3.0
        val isCompliant = voltageDropPercent <= maxAllowed

        // Calculate minimum recommended cross section for compliant drop
        val factor = if (is3Phase) 1.73205 * length * current * rho * powerFactor else 2.0 * length * current * rho
        val reqArea = factor / ((maxAllowed / 100.0) * voltage)
        val standardSizes = listOf(2.5, 4.0, 6.0, 10.0, 16.0, 25.0, 35.0, 50.0, 70.0, 95.0, 120.0, 150.0, 185.0, 240.0)
        val recMinArea = standardSizes.firstOrNull { it >= reqArea } ?: standardSizes.last()

        return CableSizingResult(
            voltageDropVolts = round(voltageDrop * 100.0) / 100.0,
            voltageDropPercent = round(voltageDropPercent * 100.0) / 100.0,
            powerLossWatts = round(powerLoss * 10.0) / 10.0,
            isCompliant = isCompliant,
            maxRecommendedPercent = maxAllowed,
            recommendedMinCrossSectionMm2 = recMinArea
        )
    }

    fun calculateTiltAndPitch(input: TiltPitchInput): TiltPitchResult {
        val lat = input.siteLatitudeDeg
        val optimalTilt = when {
            lat < 15.0 -> 15.0
            lat > 45.0 -> 40.0
            else -> round(lat * 0.9 * 10.0) / 10.0
        }

        val tiltRad = Math.toRadians(input.customTiltDeg)
        // Winter Solstice noon solar elevation: alpha = 90 - Lat - 23.45
        val noonElevationDeg = (90.0 - lat - 23.45).coerceIn(10.0, 80.0)

        // Effective solar elevation at 9:00 AM on winter solstice (~ 0.65 of noon elevation)
        val effectiveElevationDeg = (noonElevationDeg * 0.68).coerceIn(8.0, 75.0)
        val effectiveElevationRad = Math.toRadians(effectiveElevationDeg)

        val moduleSlant = max(0.5, input.moduleSlantHeightM)
        val rowHeight = moduleSlant * sin(tiltRad)
        val horizontalProjection = moduleSlant * cos(tiltRad)

        // Minimum shadow-free distance between rows
        val shadowLength = rowHeight / tan(effectiveElevationRad)
        val minPitch = horizontalProjection + shadowLength
        val clearSpacing = shadowLength

        val gcr = horizontalProjection / minPitch

        return TiltPitchResult(
            optimalFixedTiltDeg = optimalTilt,
            winterSolsticeSolarElevationDeg = round(noonElevationDeg * 10.0) / 10.0,
            minRowPitchDistanceM = round(minPitch * 100.0) / 100.0,
            groundCoverRatioGcr = round(gcr * 100.0) / 100.0,
            clearSpacingBetweenRowsM = round(clearSpacing * 100.0) / 100.0
        )
    }

    fun calculateFinancialYield(input: FinancialYieldInput): FinancialYieldResult {
        val pr = (input.performanceRatioPercent / 100.0).coerceIn(0.5, 0.95)
        val year1GenKwh = input.plantCapacityKwp * input.specificYieldKwhPerKwp * (pr / 0.8) // normalized
        val year1GrossSavings = year1GenKwh * input.tariffRatePerKwh
        val annualOmCost = input.totalInstalledCost * (input.annualOmCostPercent / 100.0)
        val year1NetSavings = year1GrossSavings - annualOmCost

        val payback = if (year1NetSavings > 0) {
            input.totalInstalledCost / year1NetSavings
        } else {
            99.0
        }

        // 25-Year Compound Savings with degradation
        var cumulativeSavings = 0.0
        var currentGen = year1GenKwh
        val degradationRate = input.annualDegradationPercent / 100.0

        for (year in 1..25) {
            val annualGross = currentGen * input.tariffRatePerKwh
            val annualNet = annualGross - annualOmCost
            cumulativeSavings += annualNet
            currentGen *= (1.0 - degradationRate)
        }

        val totalNet25Yr = cumulativeSavings - input.totalInstalledCost

        // CO2 emissions avoided: ~ 0.82 kg CO2 per kWh grid displacement
        val co2Tons = (year1GenKwh * 0.82) / 1000.0
        val trees = (co2Tons * 45).roundToInt()

        return FinancialYieldResult(
            year1GenerationKwh = round(year1GenKwh * 10.0) / 10.0,
            year1AnnualSavings = round(year1GrossSavings * 100.0) / 100.0,
            year1NetSavings = round(year1NetSavings * 100.0) / 100.0,
            paybackPeriodYears = round(payback * 10.0) / 10.0,
            cumulative25YearSavings = round(totalNet25Yr * 100.0) / 100.0,
            annualCo2OffsetTons = round(co2Tons * 10.0) / 10.0,
            equivalentTreesPlanted = trees
        )
    }
}
