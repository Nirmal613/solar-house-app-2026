package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.MaintenanceLogEntity
import com.example.ui.theme.SolarAmber
import com.example.ui.theme.SolarGreen
import com.example.ui.theme.SolarNavy
import com.example.ui.theme.SolarRed
import com.example.ui.viewmodel.SolarHouseViewModel

@Composable
fun OmManagementScreen(
    viewModel: SolarHouseViewModel,
    modifier: Modifier = Modifier
) {
    val logs by viewModel.filteredMaintenanceLogs.collectAsState()
    val activeFilter by viewModel.omCategoryFilter.collectAsState()
    var showAddDialog by remember { mutableStateOf(false) }
    var selectedLogForDetail by remember { mutableStateOf<MaintenanceLogEntity?>(null) }

    val filterOptions = listOf(
        "All",
        "Routine Preventive",
        "Breakdown Maintenance",
        "Inverter Service",
        "Quarterly Comprehensive",
        "Completed",
        "Requires Follow-up"
    )

    Scaffold(
        modifier = modifier.fillMaxSize(),
        containerColor = Color(0xFFF8FAFC),
        floatingActionButton = {
            FloatingActionButton(
                onClick = { showAddDialog = true },
                containerColor = SolarAmber,
                contentColor = SolarNavy,
                modifier = Modifier
                    .padding(bottom = 70.dp)
                    .testTag("add_om_log_fab")
            ) {
                Icon(Icons.Default.Add, contentDescription = "Log New O&M Inspection")
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Filter Chips
            LazyRow(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp),
                contentPadding = PaddingValues(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(filterOptions) { filter ->
                    FilterChip(
                        selected = activeFilter == filter,
                        onClick = { viewModel.setOmCategoryFilter(filter) },
                        label = { Text(filter, fontSize = 11.sp) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = SolarNavy,
                            selectedLabelColor = Color.White
                        )
                    )
                }
            }

            if (logs.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(32.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            imageVector = Icons.Default.Build,
                            contentDescription = null,
                            tint = Color(0xFF94A3B8),
                            modifier = Modifier.size(48.dp)
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "No maintenance logs match '$activeFilter'",
                            color = Color(0xFF64748B),
                            fontSize = 14.sp
                        )
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 16.dp),
                    contentPadding = PaddingValues(bottom = 90.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(logs, key = { it.id }) { log ->
                        MaintenanceLogCard(
                            log = log,
                            onClick = { selectedLogForDetail = log },
                            onDelete = { viewModel.deleteMaintenanceLog(log) },
                            onShareWhatsApp = {
                                val msg = """
                                    *SOLAR HOUSE O&M INSPECTION REPORT*
                                    • Site: ${log.siteName} (${log.plantCapacityKwp} kWp)
                                    • Date: ${log.inspectionDate} | Category: ${log.category}
                                    • Module Soiling: ${log.moduleCleaningStatus}
                                    • Earthing Pit Resistance: ${log.earthingResistanceOhms} Ω (${if (log.earthingResistanceOhms <= 2.0) "Optimal" else "Checked"})
                                    • Inverter Health: ${log.inverterHealth}
                                    • String Voc: ${log.stringVocMeasured}V | Isc: ${log.stringIscMeasured}A
                                    • PR Rating: ${log.performanceRatioPercent}%
                                    • Technician: ${log.technicianName}
                                    • Notes: ${log.notes}
                                """.trimIndent()
                                viewModel.openWhatsAppDialogWithMessage(msg)
                            }
                        )
                    }
                }
            }
        }
    }

    if (showAddDialog) {
        AddMaintenanceLogDialog(
            onDismiss = { showAddDialog = false },
            onConfirm = { newLog ->
                viewModel.addMaintenanceLog(newLog)
                showAddDialog = false
            }
        )
    }

    selectedLogForDetail?.let { log ->
        MaintenanceLogDetailDialog(
            log = log,
            onDismiss = { selectedLogForDetail = null },
            onShareWhatsApp = {
                val msg = """
                    *SOLAR HOUSE O&M INSPECTION REPORT*
                    • Site: ${log.siteName} (${log.plantCapacityKwp} kWp)
                    • Date: ${log.inspectionDate} | Category: ${log.category}
                    • Earthing Pit: ${log.earthingResistanceOhms} Ω | PR: ${log.performanceRatioPercent}%
                    • Inverter: ${log.inverterHealth} | Status: ${log.status}
                    • Notes: ${log.notes}
                """.trimIndent()
                viewModel.openWhatsAppDialogWithMessage(msg)
                selectedLogForDetail = null
            }
        )
    }
}

@Composable
fun MaintenanceLogCard(
    log: MaintenanceLogEntity,
    onClick: () -> Unit,
    onDelete: () -> Unit,
    onShareWhatsApp: () -> Unit
) {
    ElevatedCard(
        colors = CardDefaults.elevatedCardColors(containerColor = Color.White),
        elevation = CardDefaults.elevatedCardElevation(defaultElevation = 2.dp),
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = log.siteName,
                        fontWeight = FontWeight.Bold,
                        color = SolarNavy,
                        fontSize = 15.sp
                    )
                    Text(
                        text = "${log.plantCapacityKwp} kWp • ${log.location}",
                        color = Color(0xFF64748B),
                        fontSize = 11.sp
                    )
                }

                Surface(
                    color = when (log.status) {
                        "Completed" -> SolarGreen.copy(alpha = 0.15f)
                        "Requires Follow-up" -> SolarAmber.copy(alpha = 0.15f)
                        else -> Color(0xFFE2E8F0)
                    },
                    shape = RoundedCornerShape(6.dp)
                ) {
                    Text(
                        text = log.status,
                        color = when (log.status) {
                            "Completed" -> SolarGreen
                            "Requires Follow-up" -> SolarAmber
                            else -> Color(0xFF475569)
                        },
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Inspection Highlights Grid
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xFFF1F5F9), RoundedCornerShape(8.dp))
                    .padding(8.dp),
                horizontalArrangement = Arrangement.SpaceAround
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("Earth Pit", fontSize = 10.sp, color = Color(0xFF64748B))
                    Text(
                        "${log.earthingResistanceOhms} Ω",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (log.earthingResistanceOhms <= 2.0) SolarGreen else SolarAmber
                    )
                }
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("Inverter", fontSize = 10.sp, color = Color(0xFF64748B))
                    Text(
                        log.inverterHealth,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (log.inverterHealth == "Optimal") SolarGreen else SolarAmber
                    )
                }
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("Fleet PR", fontSize = 10.sp, color = Color(0xFF64748B))
                    Text(
                        "${log.performanceRatioPercent}%",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = SolarAmber
                    )
                }
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("Cleaning", fontSize = 10.sp, color = Color(0xFF64748B))
                    Text(
                        log.moduleCleaningStatus,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium,
                        color = SolarNavy
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = "Inspected by: ${log.technicianName} on ${log.inspectionDate}",
                fontSize = 11.sp,
                color = Color(0xFF64748B)
            )

            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onDelete, modifier = Modifier.size(28.dp)) {
                    Icon(Icons.Default.Delete, contentDescription = "Delete", tint = SolarRed, modifier = Modifier.size(16.dp))
                }

                OutlinedButton(
                    onClick = onShareWhatsApp,
                    shape = RoundedCornerShape(6.dp),
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 2.dp)
                ) {
                    Icon(Icons.Default.Chat, contentDescription = null, tint = SolarGreen, modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Send to Client / WhatsApp", fontSize = 11.sp, color = SolarGreen)
                }
            }
        }
    }
}

@Composable
fun AddMaintenanceLogDialog(
    onDismiss: () -> Unit,
    onConfirm: (MaintenanceLogEntity) -> Unit
) {
    var siteName by remember { mutableStateOf("") }
    var location by remember { mutableStateOf("") }
    var capacityStr by remember { mutableStateOf("100") }
    var inspectionDate by remember { mutableStateOf("2026-10-22") }
    var category by remember { mutableStateOf("Routine Preventive") }
    var moduleCleaning by remember { mutableStateOf("Cleaned Today") }
    var earthingOhmsStr by remember { mutableStateOf("1.6") }
    var inverterHealth by remember { mutableStateOf("Optimal") }
    var prStr by remember { mutableStateOf("82.0") }
    var vocStr by remember { mutableStateOf("630.0") }
    var iscStr by remember { mutableStateOf("13.2") }
    var technician by remember { mutableStateOf("Er. Field Engineer") }
    var notes by remember { mutableStateOf("") }
    var status by remember { mutableStateOf("Completed") }

    val categories = listOf("Routine Preventive", "Breakdown Maintenance", "Inverter Service", "Quarterly Comprehensive")
    val cleaningOptions = listOf("Cleaned Today", "Clean", "Light Soiling", "Heavy Soiling")
    val healthOptions = listOf("Optimal", "Minor Warning", "Derated", "Fault / Offline")

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text("New Field O&M Inspection Sheet", fontWeight = FontWeight.Bold, fontSize = 16.sp)
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedTextField(
                    value = siteName,
                    onValueChange = { siteName = it },
                    label = { Text("Site / Plant Name") },
                    modifier = Modifier.fillMaxWidth().testTag("om_site_name_input")
                )

                OutlinedTextField(
                    value = location,
                    onValueChange = { location = it },
                    label = { Text("Location / Rooftop Address") },
                    modifier = Modifier.fillMaxWidth().testTag("om_location_input")
                )

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = capacityStr,
                        onValueChange = { capacityStr = it },
                        label = { Text("Capacity (kWp)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = inspectionDate,
                        onValueChange = { inspectionDate = it },
                        label = { Text("Date (YYYY-MM-DD)") },
                        modifier = Modifier.weight(1f)
                    )
                }

                Text("Inspection Category:", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(categories) { cat ->
                        FilterChip(
                            selected = category == cat,
                            onClick = { category = cat },
                            label = { Text(cat, fontSize = 10.sp) }
                        )
                    }
                }

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = earthingOhmsStr,
                        onValueChange = { earthingOhmsStr = it },
                        label = { Text("Earth Pit (Ω)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = prStr,
                        onValueChange = { prStr = it },
                        label = { Text("PR Rating (%)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f)
                    )
                }

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = vocStr,
                        onValueChange = { vocStr = it },
                        label = { Text("String Voc (V)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = iscStr,
                        onValueChange = { iscStr = it },
                        label = { Text("String Isc (A)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f)
                    )
                }

                Text("Inverter Health:", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(healthOptions) { opt ->
                        FilterChip(
                            selected = inverterHealth == opt,
                            onClick = { inverterHealth = opt },
                            label = { Text(opt, fontSize = 10.sp) }
                        )
                    }
                }

                Text("Module Cleaning Status:", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(cleaningOptions) { opt ->
                        FilterChip(
                            selected = moduleCleaning == opt,
                            onClick = { moduleCleaning = opt },
                            label = { Text(opt, fontSize = 10.sp) }
                        )
                    }
                }

                OutlinedTextField(
                    value = technician,
                    onValueChange = { technician = it },
                    label = { Text("Field Engineer Name") },
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text("Inspection Notes & Observations") },
                    minLines = 3,
                    modifier = Modifier.fillMaxWidth().testTag("om_notes_input")
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (siteName.isNotBlank()) {
                        val entity = MaintenanceLogEntity(
                            siteName = siteName,
                            plantCapacityKwp = capacityStr.toDoubleOrNull() ?: 50.0,
                            location = location.ifBlank { "Rooftop" },
                            inspectionDate = inspectionDate,
                            category = category,
                            moduleCleaningStatus = moduleCleaning,
                            earthingResistanceOhms = earthingOhmsStr.toDoubleOrNull() ?: 2.0,
                            inverterHealth = inverterHealth,
                            performanceRatioPercent = prStr.toDoubleOrNull() ?: 80.0,
                            stringVocMeasured = vocStr.toDoubleOrNull() ?: 600.0,
                            stringIscMeasured = iscStr.toDoubleOrNull() ?: 13.0,
                            technicianName = technician,
                            notes = notes,
                            status = if (inverterHealth == "Optimal" && (earthingOhmsStr.toDoubleOrNull() ?: 2.0) <= 2.5) "Completed" else "Requires Follow-up"
                        )
                        onConfirm(entity)
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = SolarAmber, contentColor = SolarNavy),
                modifier = Modifier.testTag("save_om_log_confirm_btn")
            ) {
                Text("Save Inspection Sheet")
            }
        },
        dismissButton = {
            OutlinedButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}

@Composable
fun MaintenanceLogDetailDialog(
    log: MaintenanceLogEntity,
    onDismiss: () -> Unit,
    onShareWhatsApp: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(log.siteName, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                IconButton(onClick = onDismiss) {
                    Icon(Icons.Default.Close, contentDescription = "Close")
                }
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text("Location: ${log.location}", fontSize = 12.sp, color = Color(0xFF64748B))
                Text("Capacity: ${log.plantCapacityKwp} kWp", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                Text("Inspection Date: ${log.inspectionDate}", fontSize = 12.sp)
                Text("Category: ${log.category}", fontSize = 12.sp)

                Spacer(modifier = Modifier.height(4.dp))

                Surface(
                    color = Color(0xFFF1F5F9),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text("• Earthing Pit: ${log.earthingResistanceOhms} Ω (${if (log.earthingResistanceOhms <= 2.0) "Pass < 2Ω" else "Check"})", fontSize = 12.sp)
                        Text("• Inverter Status: ${log.inverterHealth}", fontSize = 12.sp)
                        Text("• Performance Ratio: ${log.performanceRatioPercent}%", fontSize = 12.sp)
                        Text("• String Voc Measured: ${log.stringVocMeasured} V", fontSize = 12.sp)
                        Text("• String Isc Measured: ${log.stringIscMeasured} A", fontSize = 12.sp)
                        Text("• Module Cleaning: ${log.moduleCleaningStatus}", fontSize = 12.sp)
                        Text("• Field Engineer: ${log.technicianName}", fontSize = 12.sp)
                    }
                }

                if (log.notes.isNotBlank()) {
                    Spacer(modifier = Modifier.height(4.dp))
                    Text("Technician Observations:", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    Text(log.notes, fontSize = 12.sp, color = Color(0xFF334155))
                }
            }
        },
        confirmButton = {
            Button(
                onClick = onShareWhatsApp,
                colors = ButtonDefaults.buttonColors(containerColor = SolarGreen, contentColor = Color.White)
            ) {
                Icon(Icons.Default.Chat, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("Send on WhatsApp")
            }
        },
        dismissButton = {
            OutlinedButton(onClick = onDismiss) {
                Text("Close")
            }
        }
    )
}
