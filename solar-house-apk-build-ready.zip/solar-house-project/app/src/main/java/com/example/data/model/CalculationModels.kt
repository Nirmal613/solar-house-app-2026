package com.example.data.model

// Plant / System Sizing
data class PlantSizingInput(
    val dailyKwhNeed: Double = 50.0,
    val peakSunHours: Double = 4.5,
    val systemLossFactorPercent: Double = 22.0, // 78% PR
    val moduleWattageWp: Double = 550.0,
    val moduleEfficiencyPercent: Double = 21.5,
    val moduleLengthM: Double = 2.278,
    val moduleWidthM: Double = 1.134,
    val targetDcAcRatio: Double = 1.25
)

data class PlantSizingResult(
    val requiredDcCapacityKwp: Double,
    val recommendedInverterAcKw: Double,
    val totalModulesCount: Int,
    val totalArrayAreaSqM: Double,
    val totalArrayAreaSqFt: Double,
    val estimatedDailyGenerationKwh: Double,
    val estimatedMonthlyGenerationKwh: Double,
    val estimatedAnnualGenerationKwh: Double
)

// String Sizing & MPPT Matching
data class StringSizingInput(
    val moduleVocStc: Double = 49.8,
    val moduleVmpStc: Double = 41.9,
    val moduleIscStc: Double = 13.9,
    val moduleImpStc: Double = 13.1,
    val tempCoeffVocPercent: Double = -0.27, // %/°C
    val tempCoeffVmpPercent: Double = -0.34, // %/°C
    val siteMinTempC: Double = -5.0,
    val siteMaxTempC: Double = 45.0,
    val maxCellTempRiseC: Double = 25.0, // Cell reaches 70°C in summer sun
    val inverterMaxDcVoltage: Double = 1000.0,
    val inverterMpptMinVoltage: Double = 200.0,
    val inverterMpptMaxVoltage: Double = 850.0,
    val inverterMaxCurrentPerMppt: Double = 26.0
)

data class StringSizingResult(
    val vocColdExtreme: Double,
    val vmpHotExtreme: Double,
    val maxModulesPerString: Int,
    val minModulesPerString: Int,
    val recommendedModulesPerString: Int,
    val maxStringsPerMppt: Int,
    val isVocWithinSafeLimit: Boolean,
    val isVmpWithinMpptRange: Boolean,
    val summaryReport: String
)

// Cable Sizing & Voltage Drop
data class CableSizingInput(
    val circuitType: String = "DC String", // "DC String", "DC Main Array", "AC Single Phase", "AC 3-Phase"
    val voltageV: Double = 600.0,
    val currentAmps: Double = 13.1,
    val oneWayLengthM: Double = 40.0,
    val conductorMaterial: String = "Copper", // "Copper" or "Aluminum"
    val cableCrossSectionMm2: Double = 4.0 // 4, 6, 10, 16, 25, 35, 50, 70, 95
)

data class CableSizingResult(
    val voltageDropVolts: Double,
    val voltageDropPercent: Double,
    val powerLossWatts: Double,
    val isCompliant: Boolean, // < 2% for DC, < 3% for AC
    val maxRecommendedPercent: Double,
    val recommendedMinCrossSectionMm2: Double
)

// Tilt & Row Pitch
data class TiltPitchInput(
    val siteLatitudeDeg: Double = 28.6, // e.g. New Delhi / Central latitude
    val customTiltDeg: Double = 25.0,
    val moduleSlantHeightM: Double = 2.3, // Collector length in tilt direction
    val tiltOrientation: String = "True South",
    val designWinterSolsticeHour: String = "9:00 AM - 3:00 PM (No Shading)"
)

data class TiltPitchResult(
    val optimalFixedTiltDeg: Double,
    val winterSolsticeSolarElevationDeg: Double,
    val minRowPitchDistanceM: Double,
    val groundCoverRatioGcr: Double,
    val clearSpacingBetweenRowsM: Double
)

// Yield, PR & Financial ROI
data class FinancialYieldInput(
    val plantCapacityKwp: Double = 50.0,
    val specificYieldKwhPerKwp: Double = 1500.0, // Annual kWh per kWp installed
    val performanceRatioPercent: Double = 78.0,
    val tariffRatePerKwh: Double = 0.12, // e.g. $0.12 or local currency
    val totalInstalledCost: Double = 42000.0,
    val annualOmCostPercent: Double = 1.5, // 1.5% of Capex
    val annualDegradationPercent: Double = 0.6
)

data class FinancialYieldResult(
    val year1GenerationKwh: Double,
    val year1AnnualSavings: Double,
    val year1NetSavings: Double,
    val paybackPeriodYears: Double,
    val cumulative25YearSavings: Double,
    val annualCo2OffsetTons: Double,
    val equivalentTreesPlanted: Int
)
