package com.example.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Calculate
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.HeadsetMic
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.SolarPower
import androidx.compose.material.icons.filled.SupportAgent
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.repository.InverterKnowledgeBase
import com.example.ui.theme.SolarAmber
import com.example.ui.theme.SolarGreen
import com.example.ui.theme.SolarNavy
import com.example.ui.theme.SolarNavyLight
import com.example.ui.theme.SolarRed
import com.example.ui.viewmodel.ScreenTab
import com.example.ui.viewmodel.SolarHouseViewModel
import com.example.util.WhatsAppHelper

@Composable
fun DashboardScreen(
    viewModel: SolarHouseViewModel,
    onNavigate: (ScreenTab) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val maintenanceLogs by viewModel.rawMaintenanceLogs.collectAsState()
    val customerTickets by viewModel.rawCustomerTickets.collectAsState()

    val totalManagedCapacity = maintenanceLogs.sumOf { it.plantCapacityKwp }
    val openTicketsCount = customerTickets.count { it.ticketStatus != "Resolved" }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFFF8FAFC)),
        contentPadding = PaddingValues(bottom = 80.dp)
    ) {
        // Hero Banner Card
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(210.dp)
            ) {
                Image(
                    painter = painterResource(id = R.drawable.img_solar_hero),
                    contentDescription = "Solar House Power Plant",
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop
                )
                // Gradient Scrim
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            brush = Brush.verticalGradient(
                                colors = listOf(
                                    Color.Transparent,
                                    SolarNavy.copy(alpha = 0.6f),
                                    SolarNavy.copy(alpha = 0.95f)
                                )
                            )
                        )
                )

                Column(
                    modifier = Modifier
                        .align(Alignment.BottomStart)
                        .padding(16.dp)
                ) {
                    Surface(
                        color = SolarAmber,
                        shape = RoundedCornerShape(4.dp),
                        modifier = Modifier.padding(bottom = 6.dp)
                    ) {
                        Text(
                            text = "EPC & O&M ENGINEERING",
                            color = SolarNavy,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.ExtraBold,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                    Text(
                        text = "Solar House Suite",
                        color = Color.White,
                        fontSize = 22.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Rooftop & Utility Solar Engineering, Plant Maintenance & Diagnostics",
                        color = Color(0xFFCBD5E1),
                        fontSize = 12.sp,
                        maxLines = 2
                    )
                }
            }
        }

        // Live KPI Metrics
        item {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "System Portfolio & Operations",
                    style = MaterialTheme.typography.titleSmall.copy(
                        fontWeight = FontWeight.Bold,
                        color = SolarNavy
                    )
                )

                Spacer(modifier = Modifier.height(10.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    KpiMetricCard(
                        title = "Managed Fleet",
                        value = "${totalManagedCapacity.toInt()} kWp",
                        sub = "${maintenanceLogs.size} Active Plants",
                        icon = Icons.Default.SolarPower,
                        accentColor = SolarAmber,
                        modifier = Modifier.weight(1f)
                    )
                    KpiMetricCard(
                        title = "Service Tickets",
                        value = "$openTicketsCount Open",
                        sub = "${customerTickets.size} Total Claims",
                        icon = Icons.Default.SupportAgent,
                        accentColor = if (openTicketsCount > 0) SolarRed else SolarGreen,
                        modifier = Modifier.weight(1f)
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    KpiMetricCard(
                        title = "Diagnostics DB",
                        value = "${InverterKnowledgeBase.faults.size} Codes",
                        sub = "9 Inverter Brands",
                        icon = Icons.Default.Warning,
                        accentColor = Color(0xFF0284C7),
                        modifier = Modifier.weight(1f)
                    )
                    KpiMetricCard(
                        title = "Health Status",
                        value = "Optimal",
                        sub = "98.4% Fleet Uptime",
                        icon = Icons.Default.CheckCircle,
                        accentColor = SolarGreen,
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }

        // Engineering Quick Actions
        item {
            Column(modifier = Modifier.padding(horizontal = 16.dp)) {
                Text(
                    text = "Engineering Tools & Modules",
                    style = MaterialTheme.typography.titleSmall.copy(
                        fontWeight = FontWeight.Bold,
                        color = SolarNavy
                    )
                )

                Spacer(modifier = Modifier.height(10.dp))

                ActionCard(
                    title = "Solar Technical Sizing",
                    subtitle = "Array sizing, String Voc cold limits, Cable drop & 25-yr financial yield",
                    icon = Icons.Default.Calculate,
                    badgeText = "5 Calculators",
                    onClick = { onNavigate(ScreenTab.CALCULATORS) },
                    testTag = "dash_action_calculators"
                )

                Spacer(modifier = Modifier.height(10.dp))

                ActionCard(
                    title = "Plant O&M Inspection Sheet",
                    subtitle = "Log preventive checklist, earthing pit ohms, string Voc/Isc and soiling",
                    icon = Icons.Default.Build,
                    badgeText = "Field Logs",
                    onClick = { onNavigate(ScreenTab.OM_MANAGEMENT) },
                    testTag = "dash_action_om"
                )

                Spacer(modifier = Modifier.height(10.dp))

                ActionCard(
                    title = "Inverter Troubleshooting",
                    subtitle = "Multi-brand fault codes (Sungrow, SMA, Huawei, SolarEdge, Solis) & test steps",
                    icon = Icons.Default.Warning,
                    badgeText = "Diagnostic Wizard",
                    onClick = { onNavigate(ScreenTab.TROUBLESHOOTING) },
                    testTag = "dash_action_troubleshoot"
                )

                Spacer(modifier = Modifier.height(10.dp))

                ActionCard(
                    title = "Customer Care & Site Surveys",
                    subtitle = "Rooftop audit inquiries, warranty claims, and customer contact tracking",
                    icon = Icons.Default.SupportAgent,
                    badgeText = "Customer Hub",
                    onClick = { onNavigate(ScreenTab.CUSTOMER_SERVICES) },
                    testTag = "dash_action_services"
                )
            }
        }

        // Emergency Breakdown & WhatsApp Support Card
        item {
            Card(
                colors = CardDefaults.cardColors(
                    containerColor = SolarNavy
                ),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
                    .testTag("hotline_support_card")
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .background(SolarAmber.copy(alpha = 0.2f), CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.HeadsetMic,
                                contentDescription = null,
                                tint = SolarAmber,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "Solar House Engineering Desk",
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp
                            )
                            Text(
                                text = "Direct WhatsApp Hotline & Emergency Breakdown",
                                color = Color(0xFF94A3B8),
                                fontSize = 11.sp
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Text(
                        text = "Need rapid assistance with string sizing verification, inverter fault clearance, or on-site O&M dispatch?",
                        color = Color(0xFFCBD5E1),
                        fontSize = 12.sp,
                        lineHeight = 16.sp
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Button(
                            onClick = {
                                viewModel.openWhatsAppDialogWithMessage(
                                    "Hello Solar House Engineering Desk, I need immediate engineering field support for our solar plant."
                                )
                            },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = SolarGreen,
                                contentColor = Color.White
                            ),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("dash_whatsapp_btn")
                        ) {
                            Icon(Icons.Default.HeadsetMic, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("WhatsApp", fontSize = 13.sp)
                        }

                        OutlinedButton(
                            onClick = {
                                WhatsAppHelper.dialPhone(context, WhatsAppHelper.DEFAULT_SOLAR_HOUSE_PHONE)
                            },
                            colors = ButtonDefaults.outlinedButtonColors(
                                contentColor = SolarAmber
                            ),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("dash_call_btn")
                        ) {
                            Icon(Icons.Default.Phone, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Call Desk", fontSize = 13.sp)
                        }
                    }
                }
            }
        }

        // Recent O&M Inspection Logs
        item {
            Column(modifier = Modifier.padding(horizontal = 16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Recent Field O&M Inspections",
                        style = MaterialTheme.typography.titleSmall.copy(
                            fontWeight = FontWeight.Bold,
                            color = SolarNavy
                        )
                    )
                    Text(
                        text = "View All (${maintenanceLogs.size})",
                        color = SolarAmber,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier
                            .clickable { onNavigate(ScreenTab.OM_MANAGEMENT) }
                            .padding(4.dp)
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))
            }
        }

        items(maintenanceLogs.take(3)) { log ->
            Card(
                colors = CardDefaults.cardColors(containerColor = Color.White),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 4.dp)
                    .clickable { onNavigate(ScreenTab.OM_MANAGEMENT) }
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = log.siteName,
                            fontWeight = FontWeight.Bold,
                            color = SolarNavy,
                            fontSize = 14.sp
                        )
                        Text(
                            text = "${log.plantCapacityKwp} kWp | ${log.category} | ${log.inspectionDate}",
                            color = Color(0xFF64748B),
                            fontSize = 11.sp
                        )
                        Text(
                            text = "Earth Pit: ${log.earthingResistanceOhms}Ω | PR: ${log.performanceRatioPercent}%",
                            color = if (log.earthingResistanceOhms <= 2.0) SolarGreen else SolarAmber,
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 11.sp
                        )
                    }

                    Surface(
                        color = when (log.status) {
                            "Completed" -> SolarGreen.copy(alpha = 0.15f)
                            "Requires Follow-up" -> SolarAmber.copy(alpha = 0.15f)
                            else -> Color(0xFFE2E8F0)
                        },
                        shape = RoundedCornerShape(6.dp)
                    ) {
                        Text(
                            text = log.status,
                            color = when (log.status) {
                                "Completed" -> SolarGreen
                                "Requires Follow-up" -> SolarAmber
                                else -> Color(0xFF475569)
                            },
                            fontWeight = FontWeight.Bold,
                            fontSize = 10.sp,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun KpiMetricCard(
    title: String,
    value: String,
    sub: String,
    icon: ImageVector,
    accentColor: Color,
    modifier: Modifier = Modifier
) {
    ElevatedCard(
        colors = CardDefaults.elevatedCardColors(containerColor = Color.White),
        elevation = CardDefaults.elevatedCardElevation(defaultElevation = 2.dp),
        shape = RoundedCornerShape(12.dp),
        modifier = modifier
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = title,
                    color = Color(0xFF64748B),
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Medium
                )
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = accentColor,
                    modifier = Modifier.size(18.dp)
                )
            }
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = value,
                color = SolarNavy,
                fontWeight = FontWeight.ExtraBold,
                fontSize = 17.sp
            )
            Text(
                text = sub,
                color = accentColor,
                fontWeight = FontWeight.SemiBold,
                fontSize = 10.sp
            )
        }
    }
}

@Composable
fun ActionCard(
    title: String,
    subtitle: String,
    icon: ImageVector,
    badgeText: String,
    onClick: () -> Unit,
    testTag: String
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .testTag(testTag)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(42.dp)
                    .background(SolarAmber.copy(alpha = 0.15f), RoundedCornerShape(8.dp)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = SolarAmber,
                    modifier = Modifier.size(24.dp)
                )
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = title,
                        fontWeight = FontWeight.Bold,
                        color = SolarNavy,
                        fontSize = 14.sp
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Surface(
                        color = Color(0xFFF1F5F9),
                        shape = RoundedCornerShape(4.dp)
                    ) {
                        Text(
                            text = badgeText,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = Color(0xFF475569),
                            modifier = Modifier.padding(horizontal = 5.dp, vertical = 2.dp)
                        )
                    }
                }
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = subtitle,
                    color = Color(0xFF64748B),
                    fontSize = 11.sp,
                    lineHeight = 15.sp
                )
            }

            Icon(
                imageVector = Icons.Default.ArrowForward,
                contentDescription = null,
                tint = Color(0xFF94A3B8),
                modifier = Modifier.size(18.dp)
            )
        }
    }
}
