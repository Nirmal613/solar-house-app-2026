package com.example.data.repository

import com.example.data.local.CustomerServiceTicketEntity
import com.example.data.local.MaintenanceLogEntity
import com.example.data.local.SavedCalculationEntity
import com.example.data.local.SolarHouseDao
import kotlinx.coroutines.flow.Flow

class SolarHouseRepository(private val dao: SolarHouseDao) {

    val allMaintenanceLogs: Flow<List<MaintenanceLogEntity>> = dao.getAllMaintenanceLogs()
    val allCustomerTickets: Flow<List<CustomerServiceTicketEntity>> = dao.getAllCustomerTickets()
    val allSavedCalculations: Flow<List<SavedCalculationEntity>> = dao.getAllSavedCalculations()

    suspend fun insertMaintenanceLog(log: MaintenanceLogEntity): Long = dao.insertMaintenanceLog(log)
    suspend fun updateMaintenanceLog(log: MaintenanceLogEntity) = dao.updateMaintenanceLog(log)
    suspend fun deleteMaintenanceLog(log: MaintenanceLogEntity) = dao.deleteMaintenanceLog(log)

    suspend fun insertCustomerTicket(ticket: CustomerServiceTicketEntity): Long = dao.insertCustomerTicket(ticket)
    suspend fun updateCustomerTicket(ticket: CustomerServiceTicketEntity) = dao.updateCustomerTicket(ticket)
    suspend fun deleteCustomerTicket(ticket: CustomerServiceTicketEntity) = dao.deleteCustomerTicket(ticket)

    suspend fun insertSavedCalculation(calc: SavedCalculationEntity): Long = dao.insertSavedCalculation(calc)
    suspend fun deleteSavedCalculation(calc: SavedCalculationEntity) = dao.deleteSavedCalculation(calc)

    suspend fun seedInitialDataIfNeeded() {
        if (dao.getMaintenanceLogsCount() == 0) {
            val initialLogs = listOf(
                MaintenanceLogEntity(
                    siteName = "Apex Logistics Solar Park",
                    plantCapacityKwp = 250.0,
                    location = "Zone B Industrial Area, Roof #4",
                    inspectionDate = "2026-10-18",
                    category = "Routine Preventive",
                    moduleCleaningStatus = "Cleaned Today",
                    earthingResistanceOhms = 1.8,
                    inverterHealth = "Optimal",
                    performanceRatioPercent = 81.4,
                    stringVocMeasured = 642.0,
                    stringIscMeasured = 13.4,
                    technicianName = "Er. Rahul Sharma",
                    notes = "Cleaned 454 panels. Checked torque on all purlin clamps. Inverter filters vacuumed.",
                    status = "Completed"
                ),
                MaintenanceLogEntity(
                    siteName = "Greenfield Cold Storage Solar",
                    plantCapacityKwp = 120.0,
                    location = "North Highway Mile 14",
                    inspectionDate = "2026-10-20",
                    category = "Inverter Service",
                    moduleCleaningStatus = "Light Soiling",
                    earthingResistanceOhms = 2.4,
                    inverterHealth = "Minor Warning",
                    performanceRatioPercent = 76.2,
                    stringVocMeasured = 598.0,
                    stringIscMeasured = 12.8,
                    technicianName = "Er. Vikram Singh",
                    notes = "Inverter #2 fan bearing has mild acoustic noise. Disconnected and lubed. Thermal scan normal.",
                    status = "Requires Follow-up"
                ),
                MaintenanceLogEntity(
                    siteName = "Horizon Textile Mill Rooftop",
                    plantCapacityKwp = 500.0,
                    location = "Industrial Corridor Sector 9",
                    inspectionDate = "2026-10-12",
                    category = "Quarterly Comprehensive",
                    moduleCleaningStatus = "Clean",
                    earthingResistanceOhms = 1.2,
                    inverterHealth = "Optimal",
                    performanceRatioPercent = 83.1,
                    stringVocMeasured = 670.0,
                    stringIscMeasured = 13.8,
                    technicianName = "Er. Priya Patel",
                    notes = "IV curve tracer test conducted on 24 strings. Degradation within 0.5% warranty specs.",
                    status = "Completed"
                )
            )
            initialLogs.forEach { dao.insertMaintenanceLog(it) }
        }

        if (dao.getCustomerTicketsCount() == 0) {
            val initialTickets = listOf(
                CustomerServiceTicketEntity(
                    customerName = "Sunrise Manufacturing Ltd",
                    customerPhone = "+919812345678",
                    siteAddress = "Plot 42, GIDC Estate, Ahmedabad",
                    requestType = "O&M Service Request",
                    systemCapacityKwp = 150.0,
                    inverterBrand = "Sungrow",
                    issueDescription = "Customer noticed PR dropped to 71%. Requests thermography scan for potential PID or module hotspots.",
                    urgency = "High",
                    ticketStatus = "In Progress"
                ),
                CustomerServiceTicketEntity(
                    customerName = "Heritage Hospital & Clinic",
                    customerPhone = "+919876501234",
                    siteAddress = "Civil Lines Road, New Delhi",
                    requestType = "New Site Survey",
                    systemCapacityKwp = 65.0,
                    inverterBrand = "Proposed Huawei",
                    issueDescription = "RCC rooftop site survey requested. Need structural load assessment and shadow simulation for adjacent water tank.",
                    urgency = "Medium",
                    ticketStatus = "Open"
                ),
                CustomerServiceTicketEntity(
                    customerName = "Balaji Agro Cold Chain",
                    customerPhone = "+919923456789",
                    siteAddress = "NH-8 Bypass, Jaipur",
                    requestType = "Inverter Warranty Claim",
                    systemCapacityKwp = 80.0,
                    inverterBrand = "Growatt",
                    issueDescription = "Inverter display showing Error 102 Residual current intermittently. Requires grounding pit rejuvenation and sensor check.",
                    urgency = "Emergency",
                    ticketStatus = "Open"
                )
            )
            initialTickets.forEach { dao.insertCustomerTicket(it) }
        }
    }
}
