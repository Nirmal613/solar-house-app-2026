package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.CustomerServiceTicketEntity
import com.example.data.local.MaintenanceLogEntity
import com.example.data.local.SavedCalculationEntity
import com.example.data.local.SolarHouseDatabase
import com.example.data.model.CableSizingInput
import com.example.data.model.CableSizingResult
import com.example.data.model.FaultCategory
import com.example.data.model.FinancialYieldInput
import com.example.data.model.FinancialYieldResult
import com.example.data.model.InverterFault
import com.example.data.model.PlantSizingInput
import com.example.data.model.PlantSizingResult
import com.example.data.model.StringSizingInput
import com.example.data.model.StringSizingResult
import com.example.data.model.TiltPitchInput
import com.example.data.model.TiltPitchResult
import com.example.data.repository.InverterKnowledgeBase
import com.example.data.repository.SolarHouseRepository
import com.example.util.SolarCalculators
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

enum class ScreenTab {
    DASHBOARD,
    CALCULATORS,
    OM_MANAGEMENT,
    TROUBLESHOOTING,
    CUSTOMER_SERVICES
}

enum class CalculatorType(val title: String) {
    PLANT_SIZING("PV & Inverter"),
    STRING_SIZING("String & MPPT"),
    CABLE_SIZING("Cable Drop"),
    TILT_PITCH("Tilt & Pitch"),
    FINANCIAL_YIELD("Yield & ROI")
}

data class UiNotification(
    val message: String,
    val isError: Boolean = false
)

class SolarHouseViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: SolarHouseRepository

    // Screen Navigation
    private val _currentTab = MutableStateFlow(ScreenTab.DASHBOARD)
    val currentTab: StateFlow<ScreenTab> = _currentTab.asStateFlow()

    // Notification / Toast banner
    private val _notification = MutableStateFlow<UiNotification?>(null)
    val notification: StateFlow<UiNotification?> = _notification.asStateFlow()

    // --- Calculator State ---
    private val _selectedCalculator = MutableStateFlow(CalculatorType.PLANT_SIZING)
    val selectedCalculator: StateFlow<CalculatorType> = _selectedCalculator.asStateFlow()

    // Plant Sizing
    val plantSizingInput = MutableStateFlow(PlantSizingInput())
    private val _plantSizingResult = MutableStateFlow(SolarCalculators.calculatePlantSizing(PlantSizingInput()))
    val plantSizingResult: StateFlow<PlantSizingResult> = _plantSizingResult.asStateFlow()

    // String Sizing
    val stringSizingInput = MutableStateFlow(StringSizingInput())
    private val _stringSizingResult = MutableStateFlow(SolarCalculators.calculateStringSizing(StringSizingInput()))
    val stringSizingResult: StateFlow<StringSizingResult> = _stringSizingResult.asStateFlow()

    // Cable Sizing
    val cableSizingInput = MutableStateFlow(CableSizingInput())
    private val _cableSizingResult = MutableStateFlow(SolarCalculators.calculateCableSizing(CableSizingInput()))
    val cableSizingResult: StateFlow<CableSizingResult> = _cableSizingResult.asStateFlow()

    // Tilt & Pitch
    val tiltPitchInput = MutableStateFlow(TiltPitchInput())
    private val _tiltPitchResult = MutableStateFlow(SolarCalculators.calculateTiltAndPitch(TiltPitchInput()))
    val tiltPitchResult: StateFlow<TiltPitchResult> = _tiltPitchResult.asStateFlow()

    // Financial Yield
    val financialYieldInput = MutableStateFlow(FinancialYieldInput())
    private val _financialYieldResult = MutableStateFlow(SolarCalculators.calculateFinancialYield(FinancialYieldInput()))
    val financialYieldResult: StateFlow<FinancialYieldResult> = _financialYieldResult.asStateFlow()

    // --- Troubleshooting State ---
    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _selectedBrand = MutableStateFlow("All Brands")
    val selectedBrand: StateFlow<String> = _selectedBrand.asStateFlow()

    private val _selectedCategory = MutableStateFlow(FaultCategory.ALL)
    val selectedCategory: StateFlow<FaultCategory> = _selectedCategory.asStateFlow()

    private val _selectedFault = MutableStateFlow<InverterFault?>(null)
    val selectedFault: StateFlow<InverterFault?> = _selectedFault.asStateFlow()

    // Filtered Faults
    val filteredFaults: StateFlow<List<InverterFault>> = combine(
        _searchQuery,
        _selectedBrand,
        _selectedCategory
    ) { query, brand, category ->
        InverterKnowledgeBase.searchFaults(query, brand, category)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), InverterKnowledgeBase.faults)

    // --- O&M State ---
    private val _omCategoryFilter = MutableStateFlow("All")
    val omCategoryFilter: StateFlow<String> = _omCategoryFilter.asStateFlow()

    val rawMaintenanceLogs: StateFlow<List<MaintenanceLogEntity>>
    val filteredMaintenanceLogs: StateFlow<List<MaintenanceLogEntity>>

    // --- Customer Tickets State ---
    private val _ticketStatusFilter = MutableStateFlow("All")
    val ticketStatusFilter: StateFlow<String> = _ticketStatusFilter.asStateFlow()

    val rawCustomerTickets: StateFlow<List<CustomerServiceTicketEntity>>
    val filteredCustomerTickets: StateFlow<List<CustomerServiceTicketEntity>>

    // Saved Calculations
    val savedCalculations: StateFlow<List<SavedCalculationEntity>>

    // WhatsApp Contact Dialog
    private val _showWhatsAppDialog = MutableStateFlow(false)
    val showWhatsAppDialog: StateFlow<Boolean> = _showWhatsAppDialog.asStateFlow()

    private val _whatsAppInitialMessage = MutableStateFlow("")
    val whatsAppInitialMessage: StateFlow<String> = _whatsAppInitialMessage.asStateFlow()

    init {
        val database = SolarHouseDatabase.getDatabase(application)
        repository = SolarHouseRepository(database.solarHouseDao())

        rawMaintenanceLogs = repository.allMaintenanceLogs.stateIn(
            viewModelScope,
            SharingStarted.WhileSubscribed(5000),
            emptyList()
        )

        filteredMaintenanceLogs = combine(rawMaintenanceLogs, _omCategoryFilter) { logs, filter ->
            if (filter == "All") logs else logs.filter { it.category == filter || it.status == filter }
        }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

        rawCustomerTickets = repository.allCustomerTickets.stateIn(
            viewModelScope,
            SharingStarted.WhileSubscribed(5000),
            emptyList()
        )

        filteredCustomerTickets = combine(rawCustomerTickets, _ticketStatusFilter) { tickets, filter ->
            if (filter == "All") tickets else tickets.filter { it.ticketStatus == filter }
        }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

        savedCalculations = repository.allSavedCalculations.stateIn(
            viewModelScope,
            SharingStarted.WhileSubscribed(5000),
            emptyList()
        )

        // Seed initial production sample data
        viewModelScope.launch {
            repository.seedInitialDataIfNeeded()
        }
    }

    fun setScreenTab(tab: ScreenTab) {
        _currentTab.value = tab
    }

    fun setSelectedCalculator(calc: CalculatorType) {
        _selectedCalculator.value = calc
    }

    fun clearNotification() {
        _notification.value = null
    }

    fun showToast(message: String, isError: Boolean = false) {
        _notification.value = UiNotification(message, isError)
    }

    // --- Calculator Recalculations ---
    fun updatePlantSizing(input: PlantSizingInput) {
        plantSizingInput.value = input
        _plantSizingResult.value = SolarCalculators.calculatePlantSizing(input)
    }

    fun updateStringSizing(input: StringSizingInput) {
        stringSizingInput.value = input
        _stringSizingResult.value = SolarCalculators.calculateStringSizing(input)
    }

    fun updateCableSizing(input: CableSizingInput) {
        cableSizingInput.value = input
        _cableSizingResult.value = SolarCalculators.calculateCableSizing(input)
    }

    fun updateTiltPitch(input: TiltPitchInput) {
        tiltPitchInput.value = input
        _tiltPitchResult.value = SolarCalculators.calculateTiltAndPitch(input)
    }

    fun updateFinancialYield(input: FinancialYieldInput) {
        financialYieldInput.value = input
        _financialYieldResult.value = SolarCalculators.calculateFinancialYield(input)
    }

    fun saveCurrentCalculation() {
        viewModelScope.launch {
            val calc = when (_selectedCalculator.value) {
                CalculatorType.PLANT_SIZING -> {
                    val res = _plantSizingResult.value
                    val inp = plantSizingInput.value
                    SavedCalculationEntity(
                        title = "${res.requiredDcCapacityKwp} kWp PV Sizing",
                        calculationType = "Plant Sizing",
                        summary = "${res.totalModulesCount} panels (${inp.moduleWattageWp.toInt()}W) | ${res.recommendedInverterAcKw} kW Inverter | ${res.estimatedDailyGenerationKwh} kWh/day",
                        details = "Daily Need: ${inp.dailyKwhNeed} kWh | Array Area: ${res.totalArrayAreaSqM} m² | Annual Yield: ${res.estimatedAnnualGenerationKwh} kWh"
                    )
                }
                CalculatorType.STRING_SIZING -> {
                    val res = _stringSizingResult.value
                    val inp = stringSizingInput.value
                    SavedCalculationEntity(
                        title = "String Sizing (${res.recommendedModulesPerString} mods/string)",
                        calculationType = "String Sizing",
                        summary = "Min: ${res.minModulesPerString} | Max: ${res.maxModulesPerString} modules/string | Voc cold: ${res.vocColdExtreme}V",
                        details = "Inverter Max V: ${inp.inverterMaxDcVoltage}V | MPPT Range: ${inp.inverterMpptMinVoltage}-${inp.inverterMpptMaxVoltage}V | Safe: ${res.isVocWithinSafeLimit}"
                    )
                }
                CalculatorType.CABLE_SIZING -> {
                    val res = _cableSizingResult.value
                    val inp = cableSizingInput.value
                    SavedCalculationEntity(
                        title = "${inp.cableCrossSectionMm2} mm² ${inp.conductorMaterial} (${inp.circuitType})",
                        calculationType = "Cable Drop",
                        summary = "Drop: ${res.voltageDropVolts}V (${res.voltageDropPercent}%) | Loss: ${res.powerLossWatts}W | Compliant: ${if (res.isCompliant) "YES" else "NO"}",
                        details = "Length: ${inp.oneWayLengthM}m | Current: ${inp.currentAmps}A | Voltage: ${inp.voltageV}V | Max Allowed: ${res.maxRecommendedPercent}%"
                    )
                }
                CalculatorType.TILT_PITCH -> {
                    val res = _tiltPitchResult.value
                    val inp = tiltPitchInput.value
                    SavedCalculationEntity(
                        title = "Tilt ${inp.customTiltDeg}° / Pitch ${res.minRowPitchDistanceM}m",
                        calculationType = "Tilt & Pitch",
                        summary = "Latitude: ${inp.siteLatitudeDeg}° | Optimal Tilt: ${res.optimalFixedTiltDeg}° | Min Pitch: ${res.minRowPitchDistanceM}m",
                        details = "GCR: ${res.groundCoverRatioGcr} | Clear Spacing: ${res.clearSpacingBetweenRowsM}m | Winter Solstice Noon Angle: ${res.winterSolsticeSolarElevationDeg}°"
                    )
                }
                CalculatorType.FINANCIAL_YIELD -> {
                    val res = _financialYieldResult.value
                    val inp = financialYieldInput.value
                    SavedCalculationEntity(
                        title = "${inp.plantCapacityKwp} kWp Yield & Payback",
                        calculationType = "Financial Yield",
                        summary = "Payback: ${res.paybackPeriodYears} yrs | Year 1 Gen: ${res.year1GenerationKwh} kWh | Net Savings: $${res.year1NetSavings}/yr",
                        details = "25-Yr Savings: $${res.cumulative25YearSavings} | CO2 Offset: ${res.annualCo2OffsetTons} Tons/yr | Trees: ${res.equivalentTreesPlanted}"
                    )
                }
            }
            repository.insertSavedCalculation(calc)
            showToast("Calculation saved to records!")
        }
    }

    fun deleteSavedCalculation(calc: SavedCalculationEntity) {
        viewModelScope.launch {
            repository.deleteSavedCalculation(calc)
            showToast("Record removed")
        }
    }

    // --- Troubleshooting Actions ---
    fun updateSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun selectBrand(brand: String) {
        _selectedBrand.value = brand
    }

    fun selectCategory(category: FaultCategory) {
        _selectedCategory.value = category
    }

    fun selectFault(fault: InverterFault?) {
        _selectedFault.value = fault
    }

    // --- O&M Actions ---
    fun setOmCategoryFilter(filter: String) {
        _omCategoryFilter.value = filter
    }

    fun addMaintenanceLog(log: MaintenanceLogEntity) {
        viewModelScope.launch {
            repository.insertMaintenanceLog(log)
            showToast("O&M Inspection Log saved for ${log.siteName}")
        }
    }

    fun updateMaintenanceLog(log: MaintenanceLogEntity) {
        viewModelScope.launch {
            repository.updateMaintenanceLog(log)
            showToast("Updated inspection record")
        }
    }

    fun deleteMaintenanceLog(log: MaintenanceLogEntity) {
        viewModelScope.launch {
            repository.deleteMaintenanceLog(log)
            showToast("Deleted inspection log")
        }
    }

    // --- Customer Service Actions ---
    fun setTicketStatusFilter(filter: String) {
        _ticketStatusFilter.value = filter
    }

    fun addCustomerTicket(ticket: CustomerServiceTicketEntity) {
        viewModelScope.launch {
            repository.insertCustomerTicket(ticket)
            showToast("Service ticket created for ${ticket.customerName}")
        }
    }

    fun updateCustomerTicketStatus(ticket: CustomerServiceTicketEntity, newStatus: String) {
        viewModelScope.launch {
            repository.updateCustomerTicket(ticket.copy(ticketStatus = newStatus))
            showToast("Ticket status updated to $newStatus")
        }
    }

    fun deleteCustomerTicket(ticket: CustomerServiceTicketEntity) {
        viewModelScope.launch {
            repository.deleteCustomerTicket(ticket)
            showToast("Service ticket deleted")
        }
    }

    // --- WhatsApp Modal ---
    fun openWhatsAppDialogWithMessage(message: String) {
        _whatsAppInitialMessage.value = message
        _showWhatsAppDialog.value = true
    }

    fun dismissWhatsAppDialog() {
        _showWhatsAppDialog.value = false
    }
}
