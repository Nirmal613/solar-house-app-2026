package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "maintenance_logs")
data class MaintenanceLogEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val siteName: String,
    val plantCapacityKwp: Double,
    val location: String,
    val inspectionDate: String,
    val category: String,
    val moduleCleaningStatus: String,
    val earthingResistanceOhms: Double,
    val inverterHealth: String,
    val performanceRatioPercent: Double,
    val stringVocMeasured: Double,
    val stringIscMeasured: Double,
    val technicianName: String,
    val notes: String,
    val status: String,
    val timestamp: Long = System.currentTimeMillis()
)
