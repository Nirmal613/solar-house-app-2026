package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [
        MaintenanceLogEntity::class,
        CustomerServiceTicketEntity::class,
        SavedCalculationEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class SolarHouseDatabase : RoomDatabase() {

    abstract fun solarHouseDao(): SolarHouseDao

    companion object {
        @Volatile
        private var INSTANCE: SolarHouseDatabase? = null

        fun getDatabase(context: Context): SolarHouseDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    SolarHouseDatabase::class.java,
                    "solar_house_database"
                )
                    .fallbackToDestructiveMigration()
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
