package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.BookmarkBorder
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.SavedCalculationEntity
import com.example.data.model.CableSizingInput
import com.example.data.model.FinancialYieldInput
import com.example.data.model.PlantSizingInput
import com.example.data.model.StringSizingInput
import com.example.data.model.TiltPitchInput
import com.example.ui.theme.SolarAmber
import com.example.ui.theme.SolarGreen
import com.example.ui.theme.SolarNavy
import com.example.ui.theme.SolarRed
import com.example.ui.viewmodel.CalculatorType
import com.example.ui.viewmodel.SolarHouseViewModel
import com.example.util.WhatsAppHelper

@Composable
fun EngineeringCalculatorsScreen(
    viewModel: SolarHouseViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val selectedCalc by viewModel.selectedCalculator.collectAsState()
    val savedCalcs by viewModel.savedCalculations.collectAsState()
    var showSavedRecords by remember { mutableStateOf(false) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFFF8FAFC))
    ) {
        // Top Calculator Switcher Tabs
        ScrollableTabRow(
            selectedTabIndex = selectedCalc.ordinal,
            containerColor = SolarNavy,
            contentColor = Color.White,
            edgePadding = 12.dp,
            indicator = { tabPositions ->
                TabRowDefaults.SecondaryIndicator(
                    modifier = Modifier.tabIndicatorOffset(tabPositions[selectedCalc.ordinal]),
                    color = SolarAmber,
                    height = 3.dp
                )
            }
        ) {
            CalculatorType.values().forEach { calc ->
                Tab(
                    selected = selectedCalc == calc,
                    onClick = {
                        viewModel.setSelectedCalculator(calc)
                        showSavedRecords = false
                    },
                    text = {
                        Text(
                            text = calc.title,
                            fontSize = 12.sp,
                            fontWeight = if (selectedCalc == calc) FontWeight.Bold else FontWeight.Normal,
                            color = if (selectedCalc == calc) SolarAmber else Color(0xFFCBD5E1)
                        )
                    },
                    modifier = Modifier.testTag("calc_tab_${calc.name.lowercase()}")
                )
            }
        }

        // Subheader with Quick Save Records Toggle
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = if (showSavedRecords) "Saved Engineering Reports" else selectedCalc.title,
                style = MaterialTheme.typography.titleMedium.copy(
                    fontWeight = FontWeight.Bold,
                    color = SolarNavy
                )
            )

            Surface(
                color = if (showSavedRecords) SolarAmber else Color(0xFFE2E8F0),
                shape = RoundedCornerShape(20.dp),
                modifier = Modifier.clickable { showSavedRecords = !showSavedRecords }
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = if (showSavedRecords) Icons.Default.Bookmark else Icons.Default.BookmarkBorder,
                        contentDescription = null,
                        tint = if (showSavedRecords) SolarNavy else Color(0xFF475569),
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "Saved (${savedCalcs.size})",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (showSavedRecords) SolarNavy else Color(0xFF475569)
                    )
                }
            }
        }

        if (showSavedRecords) {
            SavedCalculationsList(
                records = savedCalcs,
                onDelete = { viewModel.deleteSavedCalculation(it) },
                onShare = { record ->
                    val text = "SOLAR HOUSE REPORT:\n${record.title}\n${record.summary}\n${record.details}"
                    viewModel.openWhatsAppDialogWithMessage(text)
                }
            )
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 16.dp),
                contentPadding = PaddingValues(bottom = 90.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                item {
                    when (selectedCalc) {
                        CalculatorType.PLANT_SIZING -> PlantSizingView(viewModel)
                        CalculatorType.STRING_SIZING -> StringSizingView(viewModel)
                        CalculatorType.CABLE_SIZING -> CableSizingView(viewModel)
                        CalculatorType.TILT_PITCH -> TiltPitchView(viewModel)
                        CalculatorType.FINANCIAL_YIELD -> FinancialYieldView(viewModel)
                    }
                }
            }
        }
    }
}

// ----------------- 1. PLANT SIZING VIEW -----------------
@Composable
fun PlantSizingView(viewModel: SolarHouseViewModel) {
    val input by viewModel.plantSizingInput.collectAsState()
    val result by viewModel.plantSizingResult.collectAsState()

    var dailyKwhStr by remember(input) { mutableStateOf(input.dailyKwhNeed.toString()) }
    var pshStr by remember(input) { mutableStateOf(input.peakSunHours.toString()) }
    var moduleWpStr by remember(input) { mutableStateOf(input.moduleWattageWp.toInt().toString()) }
    var lossStr by remember(input) { mutableStateOf(input.systemLossFactorPercent.toString()) }
    var dcAcRatioStr by remember(input) { mutableStateOf(input.targetDcAcRatio.toString()) }

    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        ElevatedCard(
            colors = CardDefaults.elevatedCardColors(containerColor = Color.White),
            shape = RoundedCornerShape(12.dp)
        ) {
            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Plant Sizing Inputs", fontWeight = FontWeight.Bold, color = SolarNavy, fontSize = 14.sp)

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = dailyKwhStr,
                        onValueChange = {
                            dailyKwhStr = it
                            it.toDoubleOrNull()?.let { v -> viewModel.updatePlantSizing(input.copy(dailyKwhNeed = v)) }
                        },
                        label = { Text("Daily Need (kWh)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f).testTag("input_daily_kwh")
                    )
                    OutlinedTextField(
                        value = pshStr,
                        onValueChange = {
                            pshStr = it
                            it.toDoubleOrNull()?.let { v -> viewModel.updatePlantSizing(input.copy(peakSunHours = v)) }
                        },
                        label = { Text("Peak Sun (hrs/day)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f).testTag("input_psh")
                    )
                }

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = moduleWpStr,
                        onValueChange = {
                            moduleWpStr = it
                            it.toDoubleOrNull()?.let { v -> viewModel.updatePlantSizing(input.copy(moduleWattageWp = v)) }
                        },
                        label = { Text("Module (Wp)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f).testTag("input_module_wp")
                    )
                    OutlinedTextField(
                        value = dcAcRatioStr,
                        onValueChange = {
                            dcAcRatioStr = it
                            it.toDoubleOrNull()?.let { v -> viewModel.updatePlantSizing(input.copy(targetDcAcRatio = v)) }
                        },
                        label = { Text("DC:AC Ratio") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f).testTag("input_dc_ac_ratio")
                    )
                }

                OutlinedTextField(
                    value = lossStr,
                    onValueChange = {
                        lossStr = it
                        it.toDoubleOrNull()?.let { v -> viewModel.updatePlantSizing(input.copy(systemLossFactorPercent = v)) }
                    },
                    label = { Text("System Losses % (Default 22% for 78% PR)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth().testTag("input_losses")
                )
            }
        }

        // Result Card
        EngineeringResultCard(
            title = "Recommended Solar Plant Design",
            headlineMetric = "${result.requiredDcCapacityKwp} kWp",
            headlineLabel = "Required DC Capacity",
            statusBadge = "${result.totalModulesCount} Modules @ ${input.moduleWattageWp.toInt()}W",
            isSuccess = true,
            details = listOf(
                "Recommended Inverter AC" to "${result.recommendedInverterAcKw} kW (DC:AC ${input.targetDcAcRatio})",
                "Total Module Count" to "${result.totalModulesCount} Panels",
                "Required Roof / Land Area" to "${result.totalArrayAreaSqM} m² (${result.totalArrayAreaSqFt} sq.ft)",
                "Est. Daily Generation" to "${result.estimatedDailyGenerationKwh} kWh / day",
                "Est. Monthly Generation" to "${result.estimatedMonthlyGenerationKwh} kWh / month",
                "Est. Annual Generation" to "${result.estimatedAnnualGenerationKwh} kWh / year"
            ),
            onSave = { viewModel.saveCurrentCalculation() },
            onShareWhatsApp = {
                val msg = """
                    *SOLAR HOUSE PLANT SIZING SPECIFICATION*
                    • Required DC Capacity: ${result.requiredDcCapacityKwp} kWp
                    • Recommended Inverter: ${result.recommendedInverterAcKw} kW AC
                    • PV Modules: ${result.totalModulesCount} panels (${input.moduleWattageWp.toInt()} Wp)
                    • Required Area: ${result.totalArrayAreaSqM} m² (${result.totalArrayAreaSqFt} sq.ft)
                    • Daily Generation: ~${result.estimatedDailyGenerationKwh} kWh
                    • Annual Generation: ~${result.estimatedAnnualGenerationKwh} kWh
                """.trimIndent()
                viewModel.openWhatsAppDialogWithMessage(msg)
            }
        )
    }
}

// ----------------- 2. STRING SIZING VIEW -----------------
@Composable
fun StringSizingView(viewModel: SolarHouseViewModel) {
    val input by viewModel.stringSizingInput.collectAsState()
    val result by viewModel.stringSizingResult.collectAsState()

    var vocStr by remember(input) { mutableStateOf(input.moduleVocStc.toString()) }
    var vmpStr by remember(input) { mutableStateOf(input.moduleVmpStc.toString()) }
    var minTempStr by remember(input) { mutableStateOf(input.siteMinTempC.toString()) }
    var maxTempStr by remember(input) { mutableStateOf(input.siteMaxTempC.toString()) }
    var invMaxVStr by remember(input) { mutableStateOf(input.inverterMaxDcVoltage.toInt().toString()) }
    var invMpptMinStr by remember(input) { mutableStateOf(input.inverterMpptMinVoltage.toInt().toString()) }
    var invMpptMaxStr by remember(input) { mutableStateOf(input.inverterMpptMaxVoltage.toInt().toString()) }

    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        ElevatedCard(
            colors = CardDefaults.elevatedCardColors(containerColor = Color.White),
            shape = RoundedCornerShape(12.dp)
        ) {
            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("String Sizing & MPPT Parameters", fontWeight = FontWeight.Bold, color = SolarNavy, fontSize = 14.sp)

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = vocStr,
                        onValueChange = {
                            vocStr = it
                            it.toDoubleOrNull()?.let { v -> viewModel.updateStringSizing(input.copy(moduleVocStc = v)) }
                        },
                        label = { Text("Module Voc (V)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f).testTag("input_voc")
                    )
                    OutlinedTextField(
                        value = vmpStr,
                        onValueChange = {
                            vmpStr = it
                            it.toDoubleOrNull()?.let { v -> viewModel.updateStringSizing(input.copy(moduleVmpStc = v)) }
                        },
                        label = { Text("Module Vmp (V)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f).testTag("input_vmp")
                    )
                }

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = minTempStr,
                        onValueChange = {
                            minTempStr = it
                            it.toDoubleOrNull()?.let { v -> viewModel.updateStringSizing(input.copy(siteMinTempC = v)) }
                        },
                        label = { Text("Min Winter Temp (°C)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f).testTag("input_min_temp")
                    )
                    OutlinedTextField(
                        value = maxTempStr,
                        onValueChange = {
                            maxTempStr = it
                            it.toDoubleOrNull()?.let { v -> viewModel.updateStringSizing(input.copy(siteMaxTempC = v)) }
                        },
                        label = { Text("Max Summer Temp (°C)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f).testTag("input_max_temp")
                    )
                }

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = invMaxVStr,
                        onValueChange = {
                            invMaxVStr = it
                            it.toDoubleOrNull()?.let { v -> viewModel.updateStringSizing(input.copy(inverterMaxDcVoltage = v)) }
                        },
                        label = { Text("Inv Max DC (V)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f).testTag("input_inv_max_v")
                    )
                    OutlinedTextField(
                        value = invMpptMinStr,
                        onValueChange = {
                            invMpptMinStr = it
                            it.toDoubleOrNull()?.let { v -> viewModel.updateStringSizing(input.copy(inverterMpptMinVoltage = v)) }
                        },
                        label = { Text("MPPT Min (V)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f).testTag("input_mppt_min")
                    )
                    OutlinedTextField(
                        value = invMpptMaxStr,
                        onValueChange = {
                            invMpptMaxStr = it
                            it.toDoubleOrNull()?.let { v -> viewModel.updateStringSizing(input.copy(inverterMpptMaxVoltage = v)) }
                        },
                        label = { Text("MPPT Max (V)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f).testTag("input_mppt_max")
                    )
                }
            }
        }

        EngineeringResultCard(
            title = "String Sizing & Temperature Range",
            headlineMetric = "${result.recommendedModulesPerString} Modules / String",
            headlineLabel = "Recommended String Configuration",
            statusBadge = if (result.isVocWithinSafeLimit && result.isVmpWithinMpptRange) "Safe & MPPT Optimized" else "Warning: Check Voltage Range",
            isSuccess = result.isVocWithinSafeLimit && result.isVmpWithinMpptRange,
            details = listOf(
                "Safe String Range" to "${result.minModulesPerString} to ${result.maxModulesPerString} Modules",
                "Extreme Cold Voc (${input.siteMinTempC}°C)" to "${result.vocColdExtreme} V / module",
                "Extreme Hot Vmp (Summer Sun)" to "${result.vmpHotExtreme} V / module",
                "Max String Voc at Extreme Cold" to "${(result.vocColdExtreme * result.recommendedModulesPerString).toInt()} V (<= ${input.inverterMaxDcVoltage.toInt()}V Max)",
                "Min String Vmp in Peak Summer" to "${(result.vmpHotExtreme * result.recommendedModulesPerString).toInt()} V (>= ${input.inverterMpptMinVoltage.toInt()}V Min)",
                "Max Parallel Strings per MPPT" to "${result.maxStringsPerMppt} Strings"
            ),
            onSave = { viewModel.saveCurrentCalculation() },
            onShareWhatsApp = {
                val msg = """
                    *SOLAR HOUSE STRING SIZING REPORT*
                    • Configuration: ${result.recommendedModulesPerString} modules/string (Range: ${result.minModulesPerString} - ${result.maxModulesPerString})
                    • Cold Voc: ${result.vocColdExtreme}V | Hot Vmp: ${result.vmpHotExtreme}V
                    • String Voc Max: ${(result.vocColdExtreme * result.recommendedModulesPerString).toInt()}V (Under ${input.inverterMaxDcVoltage.toInt()}V limit)
                    • Status: ${if (result.isVocWithinSafeLimit) "PASSED" else "FAILED"}
                """.trimIndent()
                viewModel.openWhatsAppDialogWithMessage(msg)
            }
        )
    }
}

// ----------------- 3. CABLE SIZING VIEW -----------------
@Composable
fun CableSizingView(viewModel: SolarHouseViewModel) {
    val input by viewModel.cableSizingInput.collectAsState()
    val result by viewModel.cableSizingResult.collectAsState()

    var voltageStr by remember(input) { mutableStateOf(input.voltageV.toString()) }
    var currentStr by remember(input) { mutableStateOf(input.currentAmps.toString()) }
    var lengthStr by remember(input) { mutableStateOf(input.oneWayLengthM.toString()) }

    val circuitTypes = listOf("DC String", "DC Main Array", "AC 3-Phase", "AC Single Phase")
    val materials = listOf("Copper", "Aluminum")
    val wireSizes = listOf(2.5, 4.0, 6.0, 10.0, 16.0, 25.0, 35.0, 50.0, 70.0, 95.0)

    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        ElevatedCard(
            colors = CardDefaults.elevatedCardColors(containerColor = Color.White),
            shape = RoundedCornerShape(12.dp)
        ) {
            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Cable Circuit & Conductor", fontWeight = FontWeight.Bold, color = SolarNavy, fontSize = 14.sp)

                // Circuit Type selection
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    circuitTypes.take(2).forEach { type ->
                        FilterChip(
                            selected = input.circuitType == type,
                            onClick = { viewModel.updateCableSizing(input.copy(circuitType = type)) },
                            label = { Text(type, fontSize = 11.sp) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = SolarAmber.copy(alpha = 0.2f),
                                selectedLabelColor = SolarNavy
                            )
                        )
                    }
                }
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    circuitTypes.drop(2).forEach { type ->
                        FilterChip(
                            selected = input.circuitType == type,
                            onClick = { viewModel.updateCableSizing(input.copy(circuitType = type)) },
                            label = { Text(type, fontSize = 11.sp) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = SolarAmber.copy(alpha = 0.2f),
                                selectedLabelColor = SolarNavy
                            )
                        )
                    }
                }

                // Conductor Material
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    materials.forEach { mat ->
                        FilterChip(
                            selected = input.conductorMaterial == mat,
                            onClick = { viewModel.updateCableSizing(input.copy(conductorMaterial = mat)) },
                            label = { Text(mat, fontSize = 12.sp) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = SolarGreen.copy(alpha = 0.2f),
                                selectedLabelColor = SolarGreen
                            )
                        )
                    }
                }

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = voltageStr,
                        onValueChange = {
                            voltageStr = it
                            it.toDoubleOrNull()?.let { v -> viewModel.updateCableSizing(input.copy(voltageV = v)) }
                        },
                        label = { Text("Voltage (V)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f).testTag("input_cable_v")
                    )
                    OutlinedTextField(
                        value = currentStr,
                        onValueChange = {
                            currentStr = it
                            it.toDoubleOrNull()?.let { v -> viewModel.updateCableSizing(input.copy(currentAmps = v)) }
                        },
                        label = { Text("Current (A)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f).testTag("input_cable_i")
                    )
                }

                OutlinedTextField(
                    value = lengthStr,
                    onValueChange = {
                        lengthStr = it
                        it.toDoubleOrNull()?.let { v -> viewModel.updateCableSizing(input.copy(oneWayLengthM = v)) }
                    },
                    label = { Text("One-Way Cable Run Length (m)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth().testTag("input_cable_len")
                )

                Text("Select Cross Section Area (mm²):", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    wireSizes.take(5).forEach { size ->
                        FilterChip(
                            selected = input.cableCrossSectionMm2 == size,
                            onClick = { viewModel.updateCableSizing(input.copy(cableCrossSectionMm2 = size)) },
                            label = { Text("${size.toInt()} mm²", fontSize = 10.sp) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = SolarNavy,
                                selectedLabelColor = Color.White
                            )
                        )
                    }
                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    wireSizes.drop(5).forEach { size ->
                        FilterChip(
                            selected = input.cableCrossSectionMm2 == size,
                            onClick = { viewModel.updateCableSizing(input.copy(cableCrossSectionMm2 = size)) },
                            label = { Text("${size.toInt()} mm²", fontSize = 10.sp) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = SolarNavy,
                                selectedLabelColor = Color.White
                            )
                        )
                    }
                }
            }
        }

        EngineeringResultCard(
            title = "Voltage Drop & Power Loss Calculation",
            headlineMetric = "${result.voltageDropPercent}% Drop",
            headlineLabel = "${result.voltageDropVolts} Volts Drop across ${input.oneWayLengthM}m",
            statusBadge = if (result.isCompliant) "IEC Compliant (< ${result.maxRecommendedPercent}%)" else "NON-COMPLIANT (> ${result.maxRecommendedPercent}%)",
            isSuccess = result.isCompliant,
            details = listOf(
                "Selected Cable Size" to "${input.cableCrossSectionMm2} mm² ${input.conductorMaterial}",
                "Actual Voltage Drop" to "${result.voltageDropVolts} V (${result.voltageDropPercent}%)",
                "Circuit Power Loss" to "${result.powerLossWatts} Watts",
                "Standard Maximum Allowed" to "< ${result.maxRecommendedPercent}%",
                "Recommended Minimum Size" to "${result.recommendedMinCrossSectionMm2} mm² for compliant drop"
            ),
            onSave = { viewModel.saveCurrentCalculation() },
            onShareWhatsApp = {
                val msg = """
                    *SOLAR HOUSE CABLE SIZING REPORT*
                    • Circuit: ${input.circuitType} (${input.conductorMaterial})
                    • Cross Section: ${input.cableCrossSectionMm2} mm² | Length: ${input.oneWayLengthM}m
                    • Current: ${input.currentAmps}A | Voltage: ${input.voltageV}V
                    • Voltage Drop: ${result.voltageDropVolts}V (${result.voltageDropPercent}%)
                    • Compliance: ${if (result.isCompliant) "PASSED (< ${result.maxRecommendedPercent}%)" else "FAILED"}
                    • Recommended Min Size: ${result.recommendedMinCrossSectionMm2} mm²
                """.trimIndent()
                viewModel.openWhatsAppDialogWithMessage(msg)
            }
        )
    }
}

// ----------------- 4. TILT & PITCH VIEW -----------------
@Composable
fun TiltPitchView(viewModel: SolarHouseViewModel) {
    val input by viewModel.tiltPitchInput.collectAsState()
    val result by viewModel.tiltPitchResult.collectAsState()

    var latStr by remember(input) { mutableStateOf(input.siteLatitudeDeg.toString()) }
    var tiltStr by remember(input) { mutableStateOf(input.customTiltDeg.toString()) }
    var slantStr by remember(input) { mutableStateOf(input.moduleSlantHeightM.toString()) }

    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        ElevatedCard(
            colors = CardDefaults.elevatedCardColors(containerColor = Color.White),
            shape = RoundedCornerShape(12.dp)
        ) {
            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Solar Geometry & Row Spacing", fontWeight = FontWeight.Bold, color = SolarNavy, fontSize = 14.sp)

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = latStr,
                        onValueChange = {
                            latStr = it
                            it.toDoubleOrNull()?.let { v -> viewModel.updateTiltPitch(input.copy(siteLatitudeDeg = v)) }
                        },
                        label = { Text("Site Latitude (°N/S)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f).testTag("input_latitude")
                    )
                    OutlinedTextField(
                        value = tiltStr,
                        onValueChange = {
                            tiltStr = it
                            it.toDoubleOrNull()?.let { v -> viewModel.updateTiltPitch(input.copy(customTiltDeg = v)) }
                        },
                        label = { Text("Panel Tilt (°)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f).testTag("input_tilt")
                    )
                }

                OutlinedTextField(
                    value = slantStr,
                    onValueChange = {
                        slantStr = it
                        it.toDoubleOrNull()?.let { v -> viewModel.updateTiltPitch(input.copy(moduleSlantHeightM = v)) }
                    },
                    label = { Text("Collector Slant Length (m) (e.g. 2.3m for 1P or 4.6m for 2P)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth().testTag("input_slant")
                )
            }
        }

        EngineeringResultCard(
            title = "Shadow-Free Inter-Row Pitch",
            headlineMetric = "${result.minRowPitchDistanceM} m",
            headlineLabel = "Minimum Row-to-Row Pitch Distance",
            statusBadge = "Zero Shading (9:00 AM - 3:00 PM Winter Solstice)",
            isSuccess = true,
            details = listOf(
                "Optimal Fixed Tilt" to "${result.optimalFixedTiltDeg}° for Year-Round Yield",
                "Clear Aisle Spacing between Rows" to "${result.clearSpacingBetweenRowsM} m walkway",
                "Ground Cover Ratio (GCR)" to "${result.groundCoverRatioGcr}",
                "Winter Solstice Noon Elevation" to "${result.winterSolsticeSolarElevationDeg}°",
                "Array Orientation" to "True South (Northern Hemisphere)"
            ),
            onSave = { viewModel.saveCurrentCalculation() },
            onShareWhatsApp = {
                val msg = """
                    *SOLAR HOUSE TILT & INTER-ROW PITCH DESIGN*
                    • Site Latitude: ${input.siteLatitudeDeg}° | Panel Tilt: ${input.customTiltDeg}°
                    • Optimal Fixed Tilt: ${result.optimalFixedTiltDeg}°
                    • Min Inter-Row Pitch: ${result.minRowPitchDistanceM} m
                    • Clear Aisle Spacing: ${result.clearSpacingBetweenRowsM} m
                    • Ground Cover Ratio: ${result.groundCoverRatioGcr}
                """.trimIndent()
                viewModel.openWhatsAppDialogWithMessage(msg)
            }
        )
    }
}

// ----------------- 5. FINANCIAL YIELD VIEW -----------------
@Composable
fun FinancialYieldView(viewModel: SolarHouseViewModel) {
    val input by viewModel.financialYieldInput.collectAsState()
    val result by viewModel.financialYieldResult.collectAsState()

    var capKwpStr by remember(input) { mutableStateOf(input.plantCapacityKwp.toString()) }
    var yieldStr by remember(input) { mutableStateOf(input.specificYieldKwhPerKwp.toInt().toString()) }
    var tariffStr by remember(input) { mutableStateOf(input.tariffRatePerKwh.toString()) }
    var capexStr by remember(input) { mutableStateOf(input.totalInstalledCost.toInt().toString()) }

    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        ElevatedCard(
            colors = CardDefaults.elevatedCardColors(containerColor = Color.White),
            shape = RoundedCornerShape(12.dp)
        ) {
            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Yield & Financial Investment Parameters", fontWeight = FontWeight.Bold, color = SolarNavy, fontSize = 14.sp)

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = capKwpStr,
                        onValueChange = {
                            capKwpStr = it
                            it.toDoubleOrNull()?.let { v -> viewModel.updateFinancialYield(input.copy(plantCapacityKwp = v)) }
                        },
                        label = { Text("Plant Size (kWp)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f).testTag("input_fin_kwp")
                    )
                    OutlinedTextField(
                        value = yieldStr,
                        onValueChange = {
                            yieldStr = it
                            it.toDoubleOrNull()?.let { v -> viewModel.updateFinancialYield(input.copy(specificYieldKwhPerKwp = v)) }
                        },
                        label = { Text("Yield (kWh/kWp/yr)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f).testTag("input_fin_yield")
                    )
                }

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = tariffStr,
                        onValueChange = {
                            tariffStr = it
                            it.toDoubleOrNull()?.let { v -> viewModel.updateFinancialYield(input.copy(tariffRatePerKwh = v)) }
                        },
                        label = { Text("Grid Tariff ($/kWh)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f).testTag("input_fin_tariff")
                    )
                    OutlinedTextField(
                        value = capexStr,
                        onValueChange = {
                            capexStr = it
                            it.toDoubleOrNull()?.let { v -> viewModel.updateFinancialYield(input.copy(totalInstalledCost = v)) }
                        },
                        label = { Text("Capex ($ Total)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f).testTag("input_fin_capex")
                    )
                }
            }
        }

        EngineeringResultCard(
            title = "Solar Financial ROI & Environmental Yield",
            headlineMetric = "${result.paybackPeriodYears} Years",
            headlineLabel = "Simple Payback Period",
            statusBadge = "25-Yr Net Savings: $${result.cumulative25YearSavings.toInt()}",
            isSuccess = true,
            details = listOf(
                "Year 1 Generation" to "${result.year1GenerationKwh.toInt()} kWh",
                "Annual Gross Savings" to "$${result.year1AnnualSavings.toInt()} / year",
                "Annual Net Savings (After O&M)" to "$${result.year1NetSavings.toInt()} / year",
                "25-Year Cumulative Savings" to "$${result.cumulative25YearSavings.toInt()}",
                "Annual CO2 Offset" to "${result.annualCo2OffsetTons} Metric Tons/yr",
                "Equivalent Trees Planted" to "${result.equivalentTreesPlanted} Trees"
            ),
            onSave = { viewModel.saveCurrentCalculation() },
            onShareWhatsApp = {
                val msg = """
                    *SOLAR HOUSE FINANCIAL ROI REPORT*
                    • Plant Capacity: ${input.plantCapacityKwp} kWp | Capex: $${input.totalInstalledCost.toInt()}
                    • Payback Period: ${result.paybackPeriodYears} Years
                    • Year 1 Net Savings: $${result.year1NetSavings.toInt()} / year
                    • 25-Year Cumulative Savings: $${result.cumulative25YearSavings.toInt()}
                    • Annual CO2 Offset: ${result.annualCo2OffsetTons} Tons (${result.equivalentTreesPlanted} trees)
                """.trimIndent()
                viewModel.openWhatsAppDialogWithMessage(msg)
            }
        )
    }
}

// ----------------- GENERIC ENGINEERING RESULT CARD -----------------
@Composable
fun EngineeringResultCard(
    title: String,
    headlineMetric: String,
    headlineLabel: String,
    statusBadge: String,
    isSuccess: Boolean,
    details: List<Pair<String, String>>,
    onSave: () -> Unit,
    onShareWhatsApp: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = SolarNavy),
        shape = RoundedCornerShape(14.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = title,
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp
                )

                Surface(
                    color = if (isSuccess) SolarGreen else SolarRed,
                    shape = RoundedCornerShape(4.dp)
                ) {
                    Text(
                        text = statusBadge,
                        color = Color.White,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Big KPI
            Text(
                text = headlineMetric,
                color = SolarAmber,
                fontSize = 28.sp,
                fontWeight = FontWeight.ExtraBold
            )
            Text(
                text = headlineLabel,
                color = Color(0xFF94A3B8),
                fontSize = 12.sp
            )

            Spacer(modifier = Modifier.height(14.dp))

            // Breakdown Table
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xFF1E293B), RoundedCornerShape(8.dp))
                    .padding(10.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                details.forEach { (label, value) ->
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(text = label, color = Color(0xFFCBD5E1), fontSize = 11.sp)
                        Text(text = value, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Actions
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Button(
                    onClick = onShareWhatsApp,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = SolarGreen,
                        contentColor = Color.White
                    ),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.weight(1f).testTag("calc_share_wa_btn")
                ) {
                    Icon(Icons.Default.Chat, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("WhatsApp Report", fontSize = 12.sp)
                }

                OutlinedButton(
                    onClick = onSave,
                    colors = ButtonDefaults.outlinedButtonColors(
                        contentColor = SolarAmber
                    ),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.weight(1f).testTag("calc_save_btn")
                ) {
                    Icon(Icons.Default.Bookmark, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Save Record", fontSize = 12.sp)
                }
            }
        }
    }
}

// ----------------- SAVED CALCULATIONS LIST -----------------
@Composable
fun SavedCalculationsList(
    records: List<SavedCalculationEntity>,
    onDelete: (SavedCalculationEntity) -> Unit,
    onShare: (SavedCalculationEntity) -> Unit
) {
    if (records.isEmpty()) {
        Box(
            modifier = Modifier.fillMaxSize().padding(32.dp),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = "No saved calculations yet. Use the 'Save Record' button in any calculator to store reports here for offline reference.",
                color = Color(0xFF64748B),
                fontSize = 13.sp,
                textAlign = androidx.compose.ui.text.style.TextAlign.Center
            )
        }
    } else {
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp),
            contentPadding = PaddingValues(bottom = 90.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(records) { record ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = record.title,
                                fontWeight = FontWeight.Bold,
                                color = SolarNavy,
                                fontSize = 14.sp
                            )
                            IconButton(onClick = { onDelete(record) }, modifier = Modifier.size(28.dp)) {
                                Icon(Icons.Default.Delete, contentDescription = "Delete", tint = SolarRed, modifier = Modifier.size(18.dp))
                            }
                        }

                        Text(
                            text = record.summary,
                            color = SolarAmber,
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 12.sp
                        )

                        Spacer(modifier = Modifier.height(4.dp))

                        Text(
                            text = record.details,
                            color = Color(0xFF64748B),
                            fontSize = 11.sp
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.End
                        ) {
                            OutlinedButton(
                                onClick = { onShare(record) },
                                shape = RoundedCornerShape(6.dp),
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
                            ) {
                                Icon(Icons.Default.Chat, contentDescription = null, tint = SolarGreen, modifier = Modifier.size(14.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Send on WhatsApp", fontSize = 11.sp, color = SolarGreen)
                            }
                        }
                    }
                }
            }
        }
    }
}
