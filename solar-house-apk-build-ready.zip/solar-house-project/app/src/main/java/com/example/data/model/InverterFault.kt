package com.example.data.model

data class InverterFault(
    val id: String,
    val brand: String, // "SMA", "Sungrow", "Huawei", "SolarEdge", "Growatt", "Fronius", "GoodWe", "Solis", "Generic"
    val code: String,
    val title: String,
    val category: FaultCategory,
    val severity: FaultSeverity,
    val symptomDescription: String,
    val possibleCauses: List<String>,
    val safetyWarning: String,
    val diagnosticSteps: List<String>,
    val correctiveAction: String
)

enum class FaultCategory(val displayName: String) {
    ALL("All Categories"),
    INSULATION("Insulation & Ground"),
    GRID("Grid & Utility"),
    DC_SIDE("DC PV & Arc Fault"),
    THERMAL("Thermal & Fans"),
    COMMUNICATION("Communication & Meter"),
    INTERNAL("Internal Hardware")
}

enum class FaultSeverity(val label: String) {
    CRITICAL("Critical / Shutdown"),
    WARNING("Warning / Derating"),
    INFO("Notice / Offline")
}
