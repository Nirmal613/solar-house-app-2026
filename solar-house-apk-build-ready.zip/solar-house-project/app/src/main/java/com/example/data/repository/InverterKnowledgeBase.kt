package com.example.data.repository

import com.example.data.model.FaultCategory
import com.example.data.model.FaultSeverity
import com.example.data.model.InverterFault

object InverterKnowledgeBase {

    val faults: List<InverterFault> = listOf(
        InverterFault(
            id = "sg_039",
            brand = "Sungrow",
            code = "Fault 039 / 040",
            title = "Low Insulation Resistance (Riso)",
            category = FaultCategory.INSULATION,
            severity = FaultSeverity.CRITICAL,
            symptomDescription = "Inverter cannot connect to grid in morning or during damp weather; displays low insulation resistance error (Riso < 100kΩ / 200kΩ).",
            possibleCauses = listOf(
                "Damaged PV cable insulation contacting metal mounting structure",
                "Water ingress inside DC combiner box or MC4 connector",
                "Cracked module backsheet or damaged junction box",
                "Condensation accumulation inside inverter DC conduit"
            ),
            safetyWarning = "DANGER: HIGH DC VOLTAGE. Lethal electric shock hazard. Never open connectors or disconnect wires while PV array is under sunlight.",
            diagnosticSteps = listOf(
                "Turn off AC circuit breaker first, then open DC isolator switch.",
                "Wait 5 minutes for internal DC bus capacitors to discharge safely.",
                "Disconnect all DC PV strings from the inverter terminals.",
                "Use a calibrated 1000V DC Megohmmeter (Insulation Tester).",
                "Measure resistance between PV(+) and Earth, then between PV(-) and Earth for each individual string.",
                "Normal reading must be > 2 to 5 MΩ. If any string measures < 0.2 MΩ (200kΩ), that string has a ground fault."
            ),
            correctiveAction = "Inspect the faulty string physical wiring, inspect all MC4 crimps for water corrosion, replace damaged DC solar cables, and ensure all conduit entry glands are sealed with IP65 cable glands."
        ),
        InverterFault(
            id = "huawei_2064",
            brand = "Huawei",
            code = "Alarm 2064",
            title = "Device Abnormal / High DC Arc Fault",
            category = FaultCategory.DC_SIDE,
            severity = FaultSeverity.CRITICAL,
            symptomDescription = "Inverter AFCI (Arc Fault Circuit Interrupter) triggered; unit stops feeding power to prevent electrical fire hazard.",
            possibleCauses = listOf(
                "Loose MC4 connector crimp or mismatched cross-brand connector mating",
                "Pinched PV cable sparking against sharp edge of aluminum rail",
                "Corroded terminal screw inside DC disconnect switch",
                "Damaged solder joint inside PV module bypass diode box"
            ),
            safetyWarning = "DO NOT clear the AFCI alarm remotely without physical field inspection! Risk of rooftop electrical fire.",
            diagnosticSteps = listOf(
                "Perform full system shutdown (AC breaker OFF, DC switch OFF).",
                "Inspect all PV strings associated with the triggered MPPT input.",
                "Use a thermal imaging camera (IR) under midday solar irradiance to locate hotspots or glowing connector joints.",
                "Check every crimp pull tension and verify MC4 connectors are genuine and fully locked with audibly clicked latches."
            ),
            correctiveAction = "Cut and re-crimp all questionable MC4 connectors with certified solar ratcheting tools. Once verified intact, clear AFCI alarm via FusionSolar app or LCD panel."
        ),
        InverterFault(
            id = "sma_3501",
            brand = "SMA",
            code = "Event 3501 / 3502",
            title = "Grid Overvoltage (Vac High)",
            category = FaultCategory.GRID,
            severity = FaultSeverity.WARNING,
            symptomDescription = "Inverter trips repeatedly around solar noon (11:00 AM - 1:30 PM) with Grid Overvoltage notification.",
            possibleCauses = listOf(
                "High grid utility voltage during low local load periods",
                "Undersized AC export cable creating excessive voltage rise between inverter and main distribution panel",
                "Improper grid code parameter setting (e.g., 10-minute average voltage limit set too low)",
                "Loose neutral wire connection in AC distribution board"
            ),
            safetyWarning = "Wear insulated electrical gloves and safety glasses when probing AC distribution boards.",
            diagnosticSteps = listOf(
                "Measure phase-to-neutral (L-N) and phase-to-phase (L-L) AC voltage at the inverter terminals with True RMS Multimeter during peak generation.",
                "Measure voltage at the main utility metering panel simultaneously.",
                "Calculate AC cable voltage rise: (V_inverter - V_meter). If rise > 1.5% - 2.5%, AC cable impedance is too high.",
                "Check grid power quality log in SMA Sunny Portal."
            ),
            correctiveAction = "If AC voltage drop/rise is excessive, upgrade AC cable cross-section. If utility grid itself is running high (> 253V for 230V systems), enable Volt-Watt or Volt-VAR (Q(U)) reactive power control or contact the electrical distribution utility."
        ),
        InverterFault(
            id = "sungrow_010",
            brand = "Sungrow",
            code = "Fault 010 / 011",
            title = "Grid Undervoltage / Grid Absent (Island)",
            category = FaultCategory.GRID,
            severity = FaultSeverity.CRITICAL,
            symptomDescription = "Inverter shows Grid Lost, Islanding alarm, or Grid Undervoltage; LED status light flashes red/orange.",
            possibleCauses = listOf(
                "Utility power outage or grid line blackout",
                "Tripped AC miniature circuit breaker (MCB) or molded case breaker (MCCB)",
                "Blown AC surge protection device (SPD) or blown HRC fuse",
                "Damaged AC contactor or loose grid terminal block"
            ),
            safetyWarning = "Verify zero AC voltage across all phases with a rated voltage detector before touching AC wiring.",
            diagnosticSteps = listOf(
                "Check whether the neighborhood or main electrical facility has utility power.",
                "Inspect the dedicated solar AC breaker; reset if tripped.",
                "Measure AC line voltage between Phase and Neutral. Verify voltage is within 184V - 264V (for 230V grid).",
                "Measure frequency (should be 50.0 Hz ± 1 Hz or 60.0 Hz ± 1 Hz)."
            ),
            correctiveAction = "If utility is down, wait for grid restoration. If breaker tripped due to overload or short circuit, perform megger test on AC line before re-energizing."
        ),
        InverterFault(
            id = "solaredge_18x2c",
            brand = "SolarEdge",
            code = "Error 18x2C",
            title = "Isolation Fault / Module Level Shutdown",
            category = FaultCategory.INSULATION,
            severity = FaultSeverity.CRITICAL,
            symptomDescription = "SolarEdge inverter reports isolation fault; string safe DC voltage drops to 1V per optimizer.",
            possibleCauses = listOf(
                "Optimizer casing compromised or water ingress in optimizer connector",
                "DC wire nicked by roof tile or mounting clamp",
                "Damaged junction box diode or broken grounding wire"
            ),
            safetyWarning = "Do not bypass power optimizers. Verify system is in SafeDC mode (1V per panel).",
            diagnosticSteps = listOf(
                "Turn off inverter safety switch.",
                "Measure open circuit voltage of the string with Multimeter in DC Volts mode.",
                "Count number of optimizers: the voltage should equal exactly 1.0V per paired optimizer (e.g., 20 optimizers = 20V DC).",
                "Use SetApp or LCD test to identify specific optimizer serial number failing insulation test."
            ),
            correctiveAction = "Isolate the faulty optimizer identified by SetApp, inspect wiring, and replace defective optimizer unit under warranty."
        ),
        InverterFault(
            id = "fronius_state_306",
            brand = "Fronius",
            code = "State 306 / 307",
            title = "DC Low Current / Inactive MPPT",
            category = FaultCategory.DC_SIDE,
            severity = FaultSeverity.WARNING,
            symptomDescription = "Inverter running at derated output; one DC tracker reports current near 0 Amperes while sun is shining.",
            possibleCauses = listOf(
                "Blown internal DC fuse in combiner or inverter fuse holder",
                "String DC connector unplugged or damaged",
                "Defective bypass diode short-circuiting PV module",
                "DC switch contact failed open"
            ),
            safetyWarning = "Never pull DC fuses under load. Turn off DC switch before opening fuse holders.",
            diagnosticSteps = listOf(
                "Switch off DC isolator switch.",
                "Open the DC connection compartment.",
                "Remove and check continuity of all DC string fuses with digital multimeter ohms mode.",
                "Measure DC open-circuit voltage Voc and operating current Isc with DC clamp meter on each string."
            ),
            correctiveAction = "Replace blown 1000V/1500V gPV solar rated fuse with exact manufacturer rating (e.g. 15A or 20A gPV). Investigate what caused the overcurrent before restarting."
        ),
        InverterFault(
            id = "growatt_error_102",
            brand = "Growatt",
            code = "Error 102 / 103",
            title = "Sample Fault / Residual Current (GFDI)",
            category = FaultCategory.INSULATION,
            severity = FaultSeverity.CRITICAL,
            symptomDescription = "Residual current sensor detects AC leakage current exceeding 30mA threshold; inverter halts immediately.",
            possibleCauses = listOf(
                "Excessive capacitive leakage from wet solar array surface to grounded aluminum frames",
                "Degraded internal RCD current sensor",
                "Improperly shared neutral and earth bonding in AC sub-panel",
                "Damaged cable laying in stagnant rainwater puddle on flat roof"
            ),
            safetyWarning = "Residual leakage current indicates current flowing through ground paths; risk of electrical shock.",
            diagnosticSteps = listOf(
                "Check weather condition: heavy rain can cause momentary capacitive leakage.",
                "Inspect roof for flooded cable trays or water pooling around DC junction boxes.",
                "Elevate all DC and AC cabling on UV-resistant cable trays off the roof surface.",
                "Test system Earthing pit resistance (must be < 5 Ohms)."
            ),
            correctiveAction = "Dress and hoist all solar cables onto proper cable trays. If error persists in dry weather, perform internal sensor test or replace inverter main board."
        ),
        InverterFault(
            id = "goodwe_error_08",
            brand = "GoodWe",
            code = "Error 08 / E08",
            title = "Inverter Over-Temperature Derating",
            category = FaultCategory.THERMAL,
            severity = FaultSeverity.WARNING,
            symptomDescription = "Power output automatically drops by 20% - 60% during hot afternoon hours; thermal icon illuminated.",
            possibleCauses = listOf(
                "Inverter installed in direct blazing sunlight without sunshade canopy",
                "External cooling fan stalled, clogged by dust, or failed",
                "Inadequate side or top clearance around inverter heatsink fins",
                "Heatsink fins clogged by debris, bird nests, or dry leaves"
            ),
            safetyWarning = "Heatsink reaches temperatures exceeding 75°C (167°F). Allow to cool before touching.",
            diagnosticSteps = listOf(
                "Check inverter ambient temperature and internal temperature readout on display.",
                "Inspect cooling fans at bottom/side of unit: verify they spin freely by hand (with unit powered off).",
                "Check clearances: minimum 300mm on sides, 500mm above and below required for convection cooling.",
                "Observe whether unit is exposed to afternoon solar radiation."
            ),
            correctiveAction = "Clean heatsink fins with compressed air. Install protective solar canopy / sunshade above inverter. Replace defective cooling fans if fan test fails in service menu."
        ),
        InverterFault(
            id = "solis_error_ov_dc",
            brand = "Solis",
            code = "OV-DC (DC Overvoltage)",
            title = "PV Array String Voltage Exceeds Inverter Limit",
            category = FaultCategory.DC_SIDE,
            severity = FaultSeverity.CRITICAL,
            symptomDescription = "Inverter trips on crisp cold sunny mornings with DC Overvoltage alarm; potential permanent damage to input capacitors.",
            possibleCauses = listOf(
                "String sizing engineering error: too many modules connected in series",
                "Failure to calculate Voc temperature coefficient at sub-zero ambient temperatures",
                "Inadvertent series connection of two strings on roof"
            ),
            safetyWarning = "CRITICAL HAZARD: Overvoltage can destroy inverter MPPT semiconductors and cause DC fire.",
            diagnosticSteps = listOf(
                "Immediately turn off DC isolator switch.",
                "Measure DC open-circuit voltage (Voc) at the string input terminals.",
                "Compare measured voltage with inverter Max DC Input Voltage (e.g. 600V, 1000V, or 1100V).",
                "Calculate: Module Voc_stc * (1 + beta * (T_min - 25)) * Number of Modules."
            ),
            correctiveAction = "Re-string the array to reduce the number of modules in series by 1 or 2 panels to satisfy the maximum DC voltage constraint at the coldest recorded local temperature."
        ),
        InverterFault(
            id = "huawei_2032",
            brand = "Huawei",
            code = "Alarm 2032",
            title = "Grid Loss / Grid Power Outage",
            category = FaultCategory.GRID,
            severity = FaultSeverity.WARNING,
            symptomDescription = "Inverter enters standby mode; LED1 is steady red, LED2 is off.",
            possibleCauses = listOf(
                "Main grid supply disconnected or load shedding in progress",
                "AC output circuit breaker tripped or auxiliary contacts open",
                "AC cable disconnected or loose phase terminal"
            ),
            safetyWarning = "Treat all wires as live until verified with a multi-phase test instrument.",
            diagnosticSteps = listOf(
                "Verify whether local premises has AC mains power.",
                "Measure AC voltage between L1, L2, L3 and N on the inverter AC terminal block.",
                "Verify AC circuit breaker in the distribution panel is engaged."
            ),
            correctiveAction = "Restore grid power or reset tripped AC breaker. If AC breaker trips repeatedly, check AC cable for ground faults or short circuits."
        ),
        InverterFault(
            id = "generic_comm_loss",
            brand = "Generic",
            code = "COMM-TIMEOUT",
            title = "Datalogger / Smart Meter RS485 Communication Lost",
            category = FaultCategory.COMMUNICATION,
            severity = FaultSeverity.INFO,
            symptomDescription = "Zero-export control stops functioning, or monitoring portal shows inverter offline while generation continues.",
            possibleCauses = listOf(
                "RS485 A/B polarity reversed",
                "Loose twisted-pair comm cable screw terminal",
                "Missing 120-ohm termination resistor on long RS485 bus",
                "Incorrect Modbus address or baud rate mismatch (e.g. 9600 vs 19200)"
            ),
            safetyWarning = "Low voltage communication circuit; isolate from hazardous DC and AC power conduits.",
            diagnosticSteps = listOf(
                "Measure DC voltage between RS485 A and B terminals (normally ~ 0.2V to 3.5V DC).",
                "Check continuity of shielded twisted pair cable (CAT6 / Belden 9841).",
                "Verify Inverter Modbus ID and Smart Meter Modbus ID do not conflict."
            ),
            correctiveAction = "Correct RS485 polarity (A to A, B to B), tighten terminals, set matching baud rates in inverter settings, and enable 120Ω termination switch on the end-of-line device."
        ),
        InverterFault(
            id = "sma_relay_fail",
            brand = "SMA",
            code = "Event 4001",
            title = "Grid Relay Test Failure",
            category = FaultCategory.INTERNAL,
            severity = FaultSeverity.CRITICAL,
            symptomDescription = "Inverter performs self-test before connecting to grid and halts; internal grid disconnection relay test failed.",
            possibleCauses = listOf(
                "Welded internal relay contacts from severe grid voltage transient or lightning strike",
                "Relay drive circuit fault on inverter main control board",
                "High neutral-to-earth voltage on AC side"
            ),
            safetyWarning = "Internal relay failure prevents safe physical disconnection from grid; do not attempt uncertified component repair.",
            diagnosticSteps = listOf(
                "Disconnect AC and DC inputs completely.",
                "Wait 10 minutes, then restart system sequentially (AC first, wait 1 minute, then DC).",
                "Check neutral to earth voltage (must be < 5V AC).",
                "Listen for relay contact clicking sound during self-test sequence."
            ),
            correctiveAction = "If restart fails and error persists, contact inverter manufacturer technical support for RMA warranty replacement of internal power board."
        )
    )

    fun getBrands(): List<String> = listOf("All Brands", "SMA", "Sungrow", "Huawei", "SolarEdge", "Growatt", "Fronius", "GoodWe", "Solis", "Generic")

    fun searchFaults(query: String, brand: String, category: FaultCategory): List<InverterFault> {
        return faults.filter { fault ->
            val matchesBrand = (brand == "All Brands" || fault.brand.equals(brand, ignoreCase = true))
            val matchesCategory = (category == FaultCategory.ALL || fault.category == category)
            val matchesQuery = query.isBlank() ||
                    fault.code.contains(query, ignoreCase = true) ||
                    fault.title.contains(query, ignoreCase = true) ||
                    fault.symptomDescription.contains(query, ignoreCase = true) ||
                    fault.brand.contains(query, ignoreCase = true) ||
                    fault.possibleCauses.any { it.contains(query, ignoreCase = true) }

            matchesBrand && matchesCategory && matchesQuery
        }
    }
}
