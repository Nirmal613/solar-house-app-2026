package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.FaultCategory
import com.example.data.model.FaultSeverity
import com.example.data.model.InverterFault
import com.example.data.repository.InverterKnowledgeBase
import com.example.ui.theme.SolarAmber
import com.example.ui.theme.SolarGreen
import com.example.ui.theme.SolarNavy
import com.example.ui.theme.SolarRed
import com.example.ui.viewmodel.SolarHouseViewModel

@Composable
fun InverterTroubleshootingScreen(
    viewModel: SolarHouseViewModel,
    modifier: Modifier = Modifier
) {
    val searchQuery by viewModel.searchQuery.collectAsState()
    val selectedBrand by viewModel.selectedBrand.collectAsState()
    val selectedCategory by viewModel.selectedCategory.collectAsState()
    val faults by viewModel.filteredFaults.collectAsState()
    val selectedFault by viewModel.selectedFault.collectAsState()

    val brands = InverterKnowledgeBase.getBrands()

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFFF8FAFC))
    ) {
        // Search & Filters Header
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color.White)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { viewModel.updateSearchQuery(it) },
                placeholder = { Text("Search error code, symptom, or keyword (e.g. Riso, Arc, 3501)") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = Color(0xFF64748B)) },
                trailingIcon = {
                    if (searchQuery.isNotBlank()) {
                        IconButton(onClick = { viewModel.updateSearchQuery("") }) {
                            Icon(Icons.Default.Close, contentDescription = "Clear")
                        }
                    }
                },
                singleLine = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("inverter_search_input")
            )

            // Brand Chips
            LazyRow(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                items(brands) { brand ->
                    FilterChip(
                        selected = selectedBrand == brand,
                        onClick = { viewModel.selectBrand(brand) },
                        label = { Text(brand, fontSize = 11.sp) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = SolarAmber,
                            selectedLabelColor = SolarNavy
                        )
                    )
                }
            }

            // Category Chips
            LazyRow(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                items(FaultCategory.values()) { cat ->
                    FilterChip(
                        selected = selectedCategory == cat,
                        onClick = { viewModel.selectCategory(cat) },
                        label = { Text(cat.displayName, fontSize = 10.sp) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = SolarNavy,
                            selectedLabelColor = Color.White
                        )
                    )
                }
            }
        }

        // Faults Results
        if (faults.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(32.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = Icons.Default.Warning,
                        contentDescription = null,
                        tint = Color(0xFF94A3B8),
                        modifier = Modifier.size(48.dp)
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = "No fault codes match your filters",
                        color = Color(0xFF64748B),
                        fontSize = 14.sp
                    )
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                contentPadding = PaddingValues(bottom = 90.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(faults, key = { it.id }) { fault ->
                    InverterFaultCard(
                        fault = fault,
                        onClick = { viewModel.selectFault(fault) }
                    )
                }
            }
        }
    }

    selectedFault?.let { fault ->
        InverterDiagnosticDialog(
            fault = fault,
            onDismiss = { viewModel.selectFault(null) },
            onEscalateWhatsApp = {
                val msg = """
                    *SOLAR HOUSE INVERTER DIAGNOSTIC ESCALATION*
                    • Inverter Brand: ${fault.brand}
                    • Error Code: ${fault.code}
                    • Fault Title: ${fault.title}
                    • Category: ${fault.category.displayName}
                    • Symptom: ${fault.symptomDescription}
                    • Corrective Action Required: ${fault.correctiveAction}
                    
                    Please advise on spare parts / field escalation.
                """.trimIndent()
                viewModel.openWhatsAppDialogWithMessage(msg)
                viewModel.selectFault(null)
            }
        )
    }
}

@Composable
fun InverterFaultCard(
    fault: InverterFault,
    onClick: () -> Unit
) {
    ElevatedCard(
        colors = CardDefaults.elevatedCardColors(containerColor = Color.White),
        elevation = CardDefaults.elevatedCardElevation(defaultElevation = 2.dp),
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Surface(
                        color = SolarNavy,
                        shape = RoundedCornerShape(4.dp)
                    ) {
                        Text(
                            text = fault.brand,
                            color = Color.White,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(6.dp))

                    Surface(
                        color = SolarAmber.copy(alpha = 0.2f),
                        shape = RoundedCornerShape(4.dp)
                    ) {
                        Text(
                            text = fault.code,
                            color = SolarNavy,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.ExtraBold,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                }

                Surface(
                    color = when (fault.severity) {
                        FaultSeverity.CRITICAL -> SolarRed.copy(alpha = 0.15f)
                        FaultSeverity.WARNING -> SolarAmber.copy(alpha = 0.15f)
                        FaultSeverity.INFO -> Color(0xFFE2E8F0)
                    },
                    shape = RoundedCornerShape(4.dp)
                ) {
                    Text(
                        text = fault.severity.label,
                        color = when (fault.severity) {
                            FaultSeverity.CRITICAL -> SolarRed
                            FaultSeverity.WARNING -> SolarAmber
                            FaultSeverity.INFO -> Color(0xFF475569)
                        },
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = fault.title,
                fontWeight = FontWeight.Bold,
                color = SolarNavy,
                fontSize = 14.sp
            )

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text = fault.symptomDescription,
                color = Color(0xFF64748B),
                fontSize = 11.sp,
                maxLines = 2,
                lineHeight = 15.sp
            )

            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = fault.category.displayName,
                    fontSize = 10.sp,
                    color = Color(0xFF94A3B8),
                    fontWeight = FontWeight.Medium
                )
                Text(
                    text = "View Diagnostic Procedure →",
                    fontSize = 11.sp,
                    color = SolarAmber,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

@Composable
fun InverterDiagnosticDialog(
    fault: InverterFault,
    onDismiss: () -> Unit,
    onEscalateWhatsApp: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "${fault.brand} • ${fault.code}",
                        fontWeight = FontWeight.Bold,
                        color = SolarAmber,
                        fontSize = 14.sp
                    )
                    Text(
                        text = fault.title,
                        fontWeight = FontWeight.Bold,
                        color = SolarNavy,
                        fontSize = 16.sp
                    )
                }
                IconButton(onClick = onDismiss) {
                    Icon(Icons.Default.Close, contentDescription = "Close")
                }
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Safety Warning Banner
                Surface(
                    color = SolarRed.copy(alpha = 0.1f),
                    shape = RoundedCornerShape(8.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, SolarRed.copy(alpha = 0.3f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(10.dp),
                        verticalAlignment = Alignment.Top
                    ) {
                        Icon(
                            imageVector = Icons.Default.Warning,
                            contentDescription = null,
                            tint = SolarRed,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = fault.safetyWarning,
                            color = SolarRed,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold,
                            lineHeight = 15.sp
                        )
                    }
                }

                // Symptom
                Column {
                    Text("Symptom & Observed Behavior:", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = SolarNavy)
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(fault.symptomDescription, fontSize = 12.sp, color = Color(0xFF334155))
                }

                // Root Causes
                Column {
                    Text("Potential Root Causes:", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = SolarNavy)
                    Spacer(modifier = Modifier.height(2.dp))
                    fault.possibleCauses.forEach { cause ->
                        Row(modifier = Modifier.padding(vertical = 1.dp)) {
                            Text("• ", color = SolarAmber, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            Text(cause, fontSize = 12.sp, color = Color(0xFF475569))
                        }
                    }
                }

                // Step-by-Step Diagnostic Procedure
                Column {
                    Text("Step-by-Step Field Diagnostic Procedure:", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = SolarNavy)
                    Spacer(modifier = Modifier.height(4.dp))
                    fault.diagnosticSteps.forEachIndexed { index, step ->
                        Row(modifier = Modifier.padding(vertical = 2.dp), verticalAlignment = Alignment.Top) {
                            Surface(
                                color = SolarNavy,
                                shape = CircleShape,
                                modifier = Modifier.size(18.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Text(
                                        text = "${index + 1}",
                                        color = Color.White,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(step, fontSize = 12.sp, color = Color(0xFF1E293B), lineHeight = 16.sp)
                        }
                    }
                }

                // Corrective Action
                Surface(
                    color = SolarGreen.copy(alpha = 0.1f),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(10.dp)) {
                        Text(
                            text = "Recommended Corrective Action:",
                            fontWeight = FontWeight.Bold,
                            color = SolarGreen,
                            fontSize = 12.sp
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = fault.correctiveAction,
                            fontSize = 12.sp,
                            color = Color(0xFF065F46),
                            lineHeight = 15.sp
                        )
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = onEscalateWhatsApp,
                colors = ButtonDefaults.buttonColors(
                    containerColor = SolarGreen,
                    contentColor = Color.White
                ),
                modifier = Modifier.testTag("inverter_escalate_wa_btn")
            ) {
                Icon(Icons.Default.Chat, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("Escalate on WhatsApp")
            }
        },
        dismissButton = {
            OutlinedButton(onClick = onDismiss) {
                Text("Close")
            }
        }
    )
}
