package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Solar House Engineering Brand Colors
val SolarAmber = Color(0xFFD97706)
val SolarAmberLight = Color(0xFFFBBF24)
val SolarAmberDark = Color(0xFFB45309)
val SolarAmberContainer = Color(0xFFFEF3C7)
val OnSolarAmberContainer = Color(0xFF78350F)

val SolarNavy = Color(0xFF0F172A)
val SolarNavyLight = Color(0xFF1E293B)
val SolarNavyLighter = Color(0xFF334155)
val SolarNavyContainer = Color(0xFFE2E8F0)
val OnSolarNavyContainer = Color(0xFF0F172A)

val SolarGreen = Color(0xFF059669)
val SolarGreenLight = Color(0xFF34D399)
val SolarGreenContainer = Color(0xFFD1FAE5)
val OnSolarGreenContainer = Color(0xFF065F46)

val SolarRed = Color(0xFFDC2626)
val SolarRedContainer = Color(0xFFFEE2E2)

// Neutral surfaces
val SurfaceLight = Color(0xFFFFFFFF)
val BackgroundLight = Color(0xFFF8FAFC)
val SurfaceVariantLight = Color(0xFFF1F5F9)
val OutlineLight = Color(0xFFCBD5E1)

val SurfaceDark = Color(0xFF0F172A)
val BackgroundDark = Color(0xFF090D16)
val SurfaceVariantDark = Color(0xFF1E293B)
val OutlineDark = Color(0xFF334155)
